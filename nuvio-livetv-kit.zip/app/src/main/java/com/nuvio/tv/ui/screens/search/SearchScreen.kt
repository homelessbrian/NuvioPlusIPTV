package com.nuvio.tv.ui.screens.search

import com.nuvio.tv.ui.theme.NuvioTheme
import com.nuvio.tv.ui.screens.home.HeroBackdropState

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.KeyEvent
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import android.widget.Toast
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.focusGroup
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.platform.LocalContext
import com.nuvio.tv.ui.util.recompositionHighlighter
import com.nuvio.tv.ui.util.dpadRepeatThrottle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.nuvio.tv.ui.util.RtlKeyUtils
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.tv.material3.Button
import androidx.tv.material3.ButtonDefaults
import androidx.tv.material3.ExperimentalTvMaterial3Api
import androidx.tv.material3.IconButton as TvIconButton
import androidx.tv.material3.IconButtonDefaults as TvIconButtonDefaults
import androidx.tv.material3.Text
import com.nuvio.tv.ui.components.CatalogRowSection
import com.nuvio.tv.ui.components.EmptyScreenState
import com.nuvio.tv.ui.components.ErrorState
import com.nuvio.tv.ui.components.LoadingIndicator
import com.nuvio.tv.ui.components.PosterCardDefaults
import com.nuvio.tv.ui.components.PosterCardStyle
import com.nuvio.tv.domain.model.DiscoverLocation
import com.nuvio.tv.domain.model.stableKey
import android.view.inputmethod.CompletionInfo
import android.view.inputmethod.InputMethodManager
import androidx.compose.ui.platform.LocalView
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt
import androidx.compose.ui.res.stringResource
import com.nuvio.tv.R

/** Skeleton rows shown while a search is pending, matching the two mobile renders. */
private const val SEARCH_SKELETON_ROW_COUNT = 2

private val NAVIGATION_KEYS = setOf(
    KeyEvent.KEYCODE_DPAD_UP,
    KeyEvent.KEYCODE_DPAD_DOWN,
    KeyEvent.KEYCODE_DPAD_LEFT,
    KeyEvent.KEYCODE_DPAD_RIGHT,
    KeyEvent.KEYCODE_DPAD_CENTER,
    KeyEvent.KEYCODE_ENTER,
    KeyEvent.KEYCODE_NUMPAD_ENTER
)

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
fun SearchScreen(
    viewModel: SearchViewModel = hiltViewModel(),
    onNavigateToDetail: (String, String, String) -> Unit,
    onNavigateToSeeAll: (catalogId: String, addonId: String, type: String) -> Unit = { _, _, _ -> },
    onOpenDiscover: () -> Unit = {},
    onOpenLiveTv: () -> Unit = {},
    // Live TV fork: your provider's On Demand titles (the On Demand row).
    onOpenOnDemand: (itemId: String, itemType: String, addonBaseUrl: String?, onDemandUid: String) -> Unit = { _, _, _, _ -> },
    onPlayOnDemand: (url: String, title: String, type: String, poster: String?) -> Unit = { _, _, _, _ -> }
) {
    val uiState by viewModel.uiState.collectAsState()
    val watchedMovieIds by viewModel.watchedMovieIds.collectAsState()
    val watchedSeriesIds by viewModel.watchedSeriesIds.collectAsState()
    val context = LocalContext.current
    val view = LocalView.current
    val keyboardController = LocalSoftwareKeyboardController.current
    val strVoiceNoSpeech = stringResource(R.string.search_voice_no_speech)
    val strVoiceMicPermission = stringResource(R.string.search_voice_mic_permission)
    val strVoiceFailed = stringResource(R.string.search_voice_failed)
    val strVoiceUnavailable = stringResource(R.string.search_voice_unavailable)
    val voiceFocusRequester = remember { FocusRequester() }
    val searchFocusRequester = remember { FocusRequester() }
    val discoverFirstItemFocusRequester = remember { FocusRequester() }
    val recentClearHistoryFocusRequester = remember { FocusRequester() }
    val discoverButtonFocusRequester = remember { FocusRequester() }
    var isSearchFieldFocused by remember { mutableStateOf(false) }
    // Track the whole input row, including voice and Discover.
    var inputRowHasFocus by remember { mutableStateOf(false) }
    var isRecentSearchSectionFocused by remember { mutableStateOf(false) }
    var focusResults by remember { mutableStateOf(false) }
    var pendingFocusMoveToResultsQuery by remember { mutableStateOf<String?>(null) }
    var pendingFocusMoveSawSearching by remember { mutableStateOf(false) }
    var pendingFocusMoveHadExistingSearchRows by remember { mutableStateOf(false) }
    var isVoiceListening by remember { mutableStateOf(false) }
    var voiceRmsLevel by remember { mutableStateOf(0f) }
    var discoverFocusedItemIndex by rememberSaveable { mutableStateOf(0) }
    var restoreDiscoverFocus by rememberSaveable { mutableStateOf(false) }
    var pendingDiscoverRestoreOnResume by rememberSaveable { mutableStateOf(false) }
    val restoringSearchFocus = remember { mutableStateOf(viewModel.hasSavedSearchFocus) }
    val didRestoreSearchFocus = remember { mutableStateOf(false) }
    val lifecycleOwner = LocalLifecycleOwner.current
    val coroutineScope = rememberCoroutineScope()
    // Latches the Back-to-field step until the user navigates, types or submits. Focus alone cannot
    // lift it: closing the Fire TV keyboard moves focus into the recent searches with no key press,
    // which would otherwise re-enable this handler.
    var backToFieldLatched by remember { mutableStateOf(false) }
    val onVoiceQueryResultState = rememberUpdatedState<(String) -> Unit> { recognized ->
        if (recognized.isNotBlank()) {
            backToFieldLatched = false
            viewModel.onEvent(SearchEvent.QueryChanged(recognized))
            viewModel.onEvent(SearchEvent.SubmitSearch)
            focusResults = false
            pendingFocusMoveToResultsQuery = recognized
            pendingFocusMoveSawSearching = false
            pendingFocusMoveHadExistingSearchRows =
                uiState.submittedQuery.trim().length >= MIN_SEARCH_QUERY_LENGTH &&
                    uiState.catalogRows.any { it.items.isNotEmpty() }
        } else {
            Toast.makeText(context, strVoiceNoSpeech, Toast.LENGTH_SHORT).show()
        }
    }
    val isVoiceSearchAvailable = remember(context) { SpeechRecognizer.isRecognitionAvailable(context) }
    val topInputFocusRequester = remember(isVoiceSearchAvailable) {
        if (isVoiceSearchAvailable) voiceFocusRequester else searchFocusRequester
    }
    val speechRecognizer = remember(context, isVoiceSearchAvailable) {
        if (isVoiceSearchAvailable) {
            runCatching { SpeechRecognizer.createSpeechRecognizer(context) }.getOrNull()
        } else {
            null
        }
    }
    val buildRecognizeIntent: () -> Intent = {
        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
        }
    }
    val hasRecordAudioPermission by remember(context) {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    var recordAudioPermissionGranted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    val requestAudioPermission = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        recordAudioPermissionGranted = granted
        if (granted) {
            isVoiceListening = true
            runCatching {
                speechRecognizer?.cancel()
                speechRecognizer?.startListening(buildRecognizeIntent())
            }.onFailure {
                isVoiceListening = false
                Toast.makeText(context, strVoiceUnavailable, Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(context, strVoiceMicPermission, Toast.LENGTH_SHORT).show()
        }
    }
    LaunchedEffect(hasRecordAudioPermission) {
        recordAudioPermissionGranted = hasRecordAudioPermission
    }
    DisposableEffect(speechRecognizer) {
        val listener = object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) = Unit
            override fun onBeginningOfSpeech() = Unit
            override fun onRmsChanged(rmsdB: Float) {
                // Normalize RMS dB to 0..1 range. Typical values: -2 (silence) to 10 (loud).
                voiceRmsLevel = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
            }
            override fun onBufferReceived(buffer: ByteArray?) = Unit
            override fun onEndOfSpeech() = Unit
            override fun onEvent(eventType: Int, params: Bundle?) = Unit

            override fun onError(error: Int) {
                isVoiceListening = false
                voiceRmsLevel = 0f
                Log.w("SearchScreen", "Voice recognition error: $error")
                when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH,
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                        Toast.makeText(context, strVoiceNoSpeech, Toast.LENGTH_SHORT).show()
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY,
                    SpeechRecognizer.ERROR_CLIENT -> Unit
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                        Toast.makeText(context, strVoiceMicPermission, Toast.LENGTH_SHORT).show()
                    else ->
                        Toast.makeText(context, strVoiceFailed, Toast.LENGTH_SHORT).show()
                }
            }

            override fun onResults(results: Bundle?) {
                isVoiceListening = false
                voiceRmsLevel = 0f
                val recognized = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    .orEmpty()
                    .trim()
                onVoiceQueryResultState.value(recognized)
            }

            override fun onPartialResults(partialResults: Bundle?) = Unit
        }

        speechRecognizer?.setRecognitionListener(listener)
        onDispose {
            speechRecognizer?.setRecognitionListener(null)
            speechRecognizer?.destroy()
        }
    }
    val launchVoiceSearch: () -> Unit = {
        if (!isVoiceSearchAvailable || speechRecognizer == null) {
            Toast.makeText(context, strVoiceUnavailable, Toast.LENGTH_SHORT).show()
        } else if (!recordAudioPermissionGranted) {
            requestAudioPermission.launch(Manifest.permission.RECORD_AUDIO)
        } else {
            isVoiceListening = true
            runCatching {
                speechRecognizer.cancel()
                speechRecognizer.startListening(buildRecognizeIntent())
            }.onFailure {
                isVoiceListening = false
                Toast.makeText(context, strVoiceUnavailable, Toast.LENGTH_SHORT).show()
            }
        }
    }

    val posterCardStyle = remember(uiState.posterCardCornerRadiusDp) {
        PosterCardStyle(
            cornerRadius = uiState.posterCardCornerRadiusDp.dp,
            focusedBorderWidth = PosterCardDefaults.Style.focusedBorderWidth,
            focusedScale = PosterCardDefaults.Style.focusedScale
        )
    }

    val trimmedQuery = remember(uiState.query) { uiState.query.trim() }
    val trimmedSubmittedQuery = remember(uiState.submittedQuery) { uiState.submittedQuery.trim() }
    // Live TV fork: what this search shows (by where it was opened from: the guide and On Demand
    // as set in Live TV settings; from anywhere else, everything).
    val searchScope = com.nuvio.tv.livetv.ui.rememberSearchScope()
    // Live TV fork: matching IPTV channels and programmes.
    val liveTvResults = com.nuvio.tv.livetv.ui.rememberLiveTvSearchResults(
        query = trimmedSubmittedQuery,
        onOpened = onOpenLiveTv,
        enabled = searchScope.live
    )
    val liveTvRowFocusRequester = remember { FocusRequester() }
    val hasLiveTvResults = trimmedSubmittedQuery.length >= MIN_SEARCH_QUERY_LENGTH && liveTvResults.hits.isNotEmpty()
    // Live TV fork: your provider's own movies and series (also ones none of your addons have).
    val onDemandResults = com.nuvio.tv.livetv.ondemand.rememberOnDemandSearchResults(
        query = trimmedSubmittedQuery,
        enabled = searchScope.onDemand
    )
    val onDemandRowFocusRequester = remember { FocusRequester() }
    val hasOnDemandResults = trimmedSubmittedQuery.length >= MIN_SEARCH_QUERY_LENGTH && onDemandResults.items.isNotEmpty()
    // The first of the fork's rows (above the addon rows): where Down from the field goes.
    val hasForkResults = hasLiveTvResults || hasOnDemandResults
    val forkEntryFocusRequester = if (hasLiveTvResults) liveTvRowFocusRequester else onDemandRowFocusRequester

    // Stable per-row state maps — mirrors ClassicHomeContent pattern so
    // CatalogRowSection keeps focus when placeholder→real data transitions.
    val searchRowStates = remember { mutableMapOf<String, LazyListState>() }
    val searchRowFocusRequesters = remember { mutableMapOf<String, FocusRequester>() }
    val searchRowEntryFocusRequesters = remember { mutableMapOf<String, FocusRequester>() }
    val searchRowFocusedItemIndex = remember { mutableMapOf<String, Int>() }
    // Clears the row-local focus index so the row's entry requester moves to the first card.
    // Scoped to one row so a Back in one does not reset what the others remember.
    var focusResetCounter by remember { mutableIntStateOf(0) }
    var focusResetRowKey by remember { mutableStateOf<String?>(null) }
    // Mirrors the focused index for the active row. The map above is a plain MutableMap,
    // so its values cannot drive recomposition of the Back handler.
    val focusedResultItemIndex = remember { mutableIntStateOf(viewModel.savedFocusItemIndex.coerceAtLeast(0)) }
    var lastFocusedRowKey by remember { mutableStateOf(viewModel.savedFocusRowKey) }
    var posterOptionsRowKey by remember { mutableStateOf<String?>(null) }

    val saveSearchFocusForDetail: (String) -> Unit = { rowKey ->
        viewModel.savedFocusRowKey = rowKey
        viewModel.savedFocusItemIndex = searchRowFocusedItemIndex[rowKey] ?: 0
        viewModel.savedRowScrollPositions = searchRowStates.mapValues {
            it.value.firstVisibleItemIndex to it.value.firstVisibleItemScrollOffset
        }
        viewModel.hasSavedSearchFocus = true
    }

    // Clean up stale keys when the catalog rows change.
    val visibleRowKeys = remember(uiState.catalogRows) {
        uiState.catalogRows.mapTo(mutableSetOf()) {
            it.stableKey()
        }
    }
    // Stable list of non-empty catalog rows — mirrors ClassicHomeContent's
    // visibleHomeRows pattern so the LazyColumn receives a remember'd list.
    // Live TV fork: every search shows everything (Live TV, movies and series), wherever it
    // was opened from, unless set otherwise for the guide and On Demand in Live TV settings.
    // Back to "everything" once this search is closed for good (not while a details page it
    // opened is on top, so coming back keeps the same results).
    val searchLifecycle = androidx.compose.ui.platform.LocalLifecycleOwner.current
    remember(searchLifecycle) {
        searchLifecycle.lifecycle.addObserver(androidx.lifecycle.LifecycleEventObserver { _, e ->
            if (e == androidx.lifecycle.Lifecycle.Event.ON_DESTROY) {
                com.nuvio.tv.livetv.ui.LiveTvSearchBridge.origin.value = com.nuvio.tv.livetv.ui.LiveTvSearchBridge.HOME
            }
        })
        true
    }
    val visibleCatalogRows = remember(uiState.catalogRows, searchScope.catalog) {
        if (!searchScope.catalog) emptyList() else uiState.catalogRows.filter { it.items.isNotEmpty() }
    }
    // Live TV fork: the sections in the order set in Live TV settings (Search & Streams), only
    // the ones with results. Down from the field goes to the first; Up from each to the one above.
    val presentSections = searchScope.order.filter { kind ->
        when (kind) {
            "live" -> hasLiveTvResults
            "ondemand" -> hasOnDemandResults
            else -> visibleCatalogRows.isNotEmpty()
        }
    }
    fun sectionEntry(kind: String): FocusRequester? = when (kind) {
        "live" -> liveTvRowFocusRequester
        "ondemand" -> onDemandRowFocusRequester
        else -> null // the addon rows: their own focus handling
    }
    /** What Up from a section's first row goes to: the section above it, or the search field. */
    fun sectionUp(kind: String): FocusRequester? {
        val i = presentSections.indexOf(kind)
        if (i <= 0) return searchFocusRequester
        // Below the addon rows: plain Up reaches their last row.
        return sectionEntry(presentSections[i - 1])
    }
    val catalogIndexInOrder = searchScope.order.indexOf("catalog").coerceAtLeast(0)
    val forkBeforeCatalog = searchScope.order.take(catalogIndexInOrder)
    val forkAfterCatalog = searchScope.order.drop(catalogIndexInOrder + 1)
    LaunchedEffect(visibleRowKeys) {
        searchRowStates.keys.retainAll(visibleRowKeys)
        searchRowFocusRequesters.keys.retainAll(visibleRowKeys)
        searchRowEntryFocusRequesters.keys.retainAll(visibleRowKeys)
        searchRowFocusedItemIndex.keys.retainAll(visibleRowKeys)
    }

    val isDiscoverMode = remember(uiState.discoverLocation, trimmedQuery, trimmedSubmittedQuery) {
        shouldShowDiscoverInSearch(
            discoverLocation = uiState.discoverLocation,
            query = trimmedQuery,
            submittedQuery = trimmedSubmittedQuery
        )
    }
    LaunchedEffect(isDiscoverMode) {
        if (isDiscoverMode) viewModel.ensureDiscoverLoaded()
    }
    val hasPendingUnsubmittedQuery = remember(isDiscoverMode, trimmedQuery, trimmedSubmittedQuery) {
        !isDiscoverMode &&
            trimmedQuery.length >= MIN_SEARCH_QUERY_LENGTH &&
            trimmedQuery != trimmedSubmittedQuery
    }
    val showRecentSearches = remember(
        trimmedQuery,
        uiState.recentSearches
    ) {
        trimmedQuery.isEmpty() &&
            uiState.recentSearches.isNotEmpty()
    }
    val canMoveToResults = remember(
        isDiscoverMode,
        uiState.discoverResults,
        trimmedSubmittedQuery,
        uiState.catalogRows
    ) {
        if (isDiscoverMode) {
            false
        } else {
            trimmedSubmittedQuery.length >= MIN_SEARCH_QUERY_LENGTH &&
                uiState.catalogRows.any { it.items.isNotEmpty() }
        }
    }
    val submitCurrentQuery: (String) -> Unit = { submittedQuery ->
        viewModel.onEvent(SearchEvent.SubmitSearch)
        // Submitting moves focus into the results without a key event on an on-screen keyboard.
        backToFieldLatched = false
        focusResults = false
        if (submittedQuery.length >= MIN_SEARCH_QUERY_LENGTH) {
            pendingFocusMoveToResultsQuery = submittedQuery
            pendingFocusMoveSawSearching = false
            pendingFocusMoveHadExistingSearchRows =
                trimmedSubmittedQuery.length >= MIN_SEARCH_QUERY_LENGTH &&
                    uiState.catalogRows.any { row -> row.items.isNotEmpty() }
        } else {
            pendingFocusMoveToResultsQuery = null
            pendingFocusMoveSawSearching = false
            pendingFocusMoveHadExistingSearchRows = false
        }
    }
    // Live TV fork: a programme sent from the TV guide ("Find & stream in Nuvio").
    LaunchedEffect(Unit) {
        com.nuvio.tv.livetv.ui.LiveTvSearchBridge.pending.collect { title ->
            if (title == null) return@collect
            com.nuvio.tv.livetv.ui.LiveTvSearchBridge.consume()
            viewModel.onEvent(SearchEvent.QueryChanged(title))
            submitCurrentQuery(title)
        }
    }
    val handleQueryChanged: (String) -> Unit = { nextQuery ->
        // A real edit is user intent. An IME that re-commits the same text on dismiss is not.
        if (nextQuery != uiState.query) backToFieldLatched = false
        val previousQuery = uiState.query.trim()
        val trimmedNextQuery = nextQuery.trim()
        val selectedSuggestion = trimmedNextQuery.length >= MIN_SEARCH_QUERY_LENGTH &&
            trimmedNextQuery != trimmedSubmittedQuery &&
            uiState.suggestions.any { it.equals(trimmedNextQuery, ignoreCase = true) } &&
            trimmedNextQuery.startsWith(previousQuery, ignoreCase = true) &&
            trimmedNextQuery.length - previousQuery.length > 1

        focusResults = false
        pendingFocusMoveToResultsQuery = null
        pendingFocusMoveSawSearching = false
        pendingFocusMoveHadExistingSearchRows = false
        viewModel.onEvent(SearchEvent.QueryChanged(nextQuery))
        if (selectedSuggestion) {
            submitCurrentQuery(trimmedNextQuery)
        }
    }
    val submitRecentSearch: (String) -> Unit = { recentQuery ->
        val trimmedRecentQuery = recentQuery.trim()
        if (trimmedRecentQuery.isNotEmpty()) {
            runCatching { topInputFocusRequester.requestFocus() }
            viewModel.onEvent(SearchEvent.QueryChanged(trimmedRecentQuery))
            submitCurrentQuery(trimmedRecentQuery)
        }
    }

    LaunchedEffect(focusResults, isDiscoverMode, uiState.discoverResults.size) {
        if (focusResults && isDiscoverMode && uiState.discoverResults.isNotEmpty()) {
            delay(100)
            runCatching { discoverFirstItemFocusRequester.requestFocus() }
            focusResults = false
            pendingFocusMoveToResultsQuery = null
            pendingFocusMoveSawSearching = false
            pendingFocusMoveHadExistingSearchRows = false
        }
    }

    LaunchedEffect(
        pendingFocusMoveToResultsQuery,
        pendingFocusMoveSawSearching,
        pendingFocusMoveHadExistingSearchRows,
        uiState.isSearching,
        uiState.submittedQuery,
        canMoveToResults,
        isDiscoverMode
    ) {
        val pendingQuery = pendingFocusMoveToResultsQuery ?: return@LaunchedEffect
        val currentSubmittedQuery = uiState.submittedQuery.trim()
        if (currentSubmittedQuery != pendingQuery) return@LaunchedEffect

        if (uiState.isSearching) {
            pendingFocusMoveSawSearching = true
            return@LaunchedEffect
        }

        val shouldRequireSeenSearching = pendingFocusMoveHadExistingSearchRows
        if ((shouldRequireSeenSearching && !pendingFocusMoveSawSearching) || !canMoveToResults) {
            return@LaunchedEffect
        }

        if (isDiscoverMode) {
            focusResults = true
        } else {
            // Use explicit first-item focus for deterministic landing on row 1 / column 1.
            delay(80)
            focusResults = true
        }
        pendingFocusMoveToResultsQuery = null
        pendingFocusMoveSawSearching = false
        pendingFocusMoveHadExistingSearchRows = false
    }

    val initialFocusRequester = topInputFocusRequester

    LaunchedEffect(Unit) {
        if (viewModel.hasSavedSearchFocus) return@LaunchedEffect
        if (pendingDiscoverRestoreOnResume || restoreDiscoverFocus) return@LaunchedEffect
        repeat(2) { withFrameNanos { } }
        runCatching { initialFocusRequester.requestFocus() }
    }

    // Restore the Discover button after returning.
    LaunchedEffect(restoreDiscoverFocus) {
        if (!restoreDiscoverFocus) return@LaunchedEffect
        repeat(2) { withFrameNanos { } }
        runCatching { discoverButtonFocusRequester.requestFocus() }
        restoreDiscoverFocus = false
    }

    // Push search suggestions to the native keyboard suggestion bar. Keyed on the query as well
    // as the list: the keyboard rebuilds its strip as the query changes, so completions have to
    // be pushed again even when the list is unchanged.
    LaunchedEffect(uiState.query, uiState.suggestions) {
        val imm = context.getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as? InputMethodManager
            ?: return@LaunchedEffect
        val completions = uiState.suggestions.mapIndexed { index, name ->
            CompletionInfo(index.toLong(), index, name)
        }.toTypedArray()
        imm.displayCompletions(view, completions)
    }

    var isScreenActive by remember { mutableStateOf(true) }
    val latestPendingDiscoverRestore by rememberUpdatedState(pendingDiscoverRestoreOnResume)
    val latestInitialFocusRequester by rememberUpdatedState(initialFocusRequester)
    val latestShouldKeepSearchFocus by rememberUpdatedState(
        focusResults || uiState.isSearching || isVoiceListening
    )
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                isScreenActive = true
                if (latestPendingDiscoverRestore) {
                    restoreDiscoverFocus = true
                    pendingDiscoverRestoreOnResume = false
                } else if (viewModel.hasSavedSearchFocus || didRestoreSearchFocus.value) {
                    // Returning from details — don't steal focus, CatalogRowSection
                    // already restored it or will restore it via focusedItemIndex.
                    didRestoreSearchFocus.value = false
                } else if (!latestShouldKeepSearchFocus) {
                    // Keep resume and entry consistent; ON_RESUME also fires on entry.
                    coroutineScope.launch {
                        repeat(2) { withFrameNanos { } }
                        runCatching { latestInitialFocusRequester.requestFocus() }
                    }
                }
            } else if (event == Lifecycle.Event.ON_PAUSE) {
                isScreenActive = false
                keyboardController?.hide()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .onPreviewKeyEvent { keyEvent ->
                if (keyEvent.nativeKeyEvent.action == KeyEvent.ACTION_DOWN &&
                    keyEvent.nativeKeyEvent.keyCode in NAVIGATION_KEYS
                ) {
                    backToFieldLatched = false
                }
                false
            }
            .background(NuvioTheme.colors.Background),
        contentAlignment = Alignment.TopCenter
    ) {
        // Live TV fork: a channel picked in the results plays behind them (TiviMate style).
        com.nuvio.tv.livetv.ui.LiveTvSearchPreview(liveTvResults, Modifier.matchParentSize())
        val listState = rememberLazyListState()

        // Step back within Search before falling through to the root handler.
        val focusedRowKey = lastFocusedRowKey
        val focusedItemIndex = focusedResultItemIndex.intValue
        BackHandler(
            enabled = !inputRowHasFocus && !backToFieldLatched &&
                (isRecentSearchSectionFocused || (!isDiscoverMode && focusedRowKey != null))
        ) {
            if (!isRecentSearchSectionFocused && focusedItemIndex > 0 && focusedRowKey != null) {
                searchRowFocusedItemIndex[focusedRowKey] = 0
                focusedResultItemIndex.intValue = 0
                focusResetRowKey = focusedRowKey
                focusResetCounter++
                coroutineScope.launch {
                    // Let the reset take effect so the entry requester moves to the first card.
                    repeat(2) { withFrameNanos { } }
                    searchRowStates[focusedRowKey]?.scrollToItem(0)
                    searchRowEntryFocusRequesters[focusedRowKey]
                        ?.let { runCatching { it.requestFocus() } }
                }
            } else {
                backToFieldLatched = true
                coroutineScope.launch {
                    listState.scrollToItem(0)
                    runCatching { searchFocusRequester.requestFocus() }
                    // The focus request can start an input session and show the keyboard.
                    keyboardController?.hide()
                }
            }
        }

        // Skip the initial composition; there is nothing stale to reset yet.
        var lastScrollResetQuery by remember { mutableStateOf(uiState.query) }
        LaunchedEffect(uiState.query) {
            if (uiState.query == lastScrollResetQuery) return@LaunchedEffect
            lastScrollResetQuery = uiState.query
            // Clear stale focus so the restorer cannot return to an item from the previous query.
            searchRowFocusedItemIndex.clear()
            focusedResultItemIndex.intValue = 0
            // Clear saved offsets too; rebuilt rows can otherwise inherit the old query's position.
            viewModel.savedRowScrollPositions = emptyMap()
            listState.scrollToItem(0)
            // Snapshot the states because scrollToItem suspends.
            searchRowStates.values.toList().forEach { it.scrollToItem(0) }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .recompositionHighlighter()
                .dpadRepeatThrottle(),
            state = listState,
            contentPadding = PaddingValues(
                top = if (isDiscoverMode) 10.dp else NuvioTheme.spacing.lg,
                bottom = NuvioTheme.spacing.lg
            ),
            verticalArrangement = Arrangement.spacedBy(NuvioTheme.spacing.lg)
        ) {
            item(key = "search_input") {
                SearchInputField(
                    modifier = Modifier.onFocusChanged { inputRowHasFocus = it.hasFocus },
                    query = uiState.query,
                    canMoveToResults = (canMoveToResults && searchScope.catalog) || hasForkResults,
                    voiceFocusRequester = if (isVoiceSearchAvailable) voiceFocusRequester else null,
                    searchFocusRequester = searchFocusRequester,
                    onSearchFieldFocusChanged = { focused -> isSearchFieldFocused = focused },
                    onQueryChanged = handleQueryChanged,
                    onSubmit = {
                        submitCurrentQuery(uiState.query.trim())
                    },
                    showVoiceSearch = isVoiceSearchAvailable,
                    isVoiceListening = isVoiceListening,
                    voiceRmsLevel = voiceRmsLevel,
                    onVoiceSearch = launchVoiceSearch,
                    onMoveToResults = {
                        // D-pad down from the text field is the user's confirmation that the
                        // live-search results are useful, even before a particular card opens.
                        viewModel.onEvent(SearchEvent.RememberSearchFromTextInput)
                        // Live TV fork: to the first section in the set order (Live TV or On Demand
                        // when they come first; otherwise the addon rows, as usual).
                        val firstEntry = presentSections.firstOrNull()?.let { sectionEntry(it) }
                        if (firstEntry != null && runCatching { firstEntry.requestFocus() }.isSuccess) {
                            focusResults = false
                        } else {
                            focusResults = true
                        }
                    },
                    onOpenDiscover = {
                        // Arm the restore so coming back lands on this button rather than the
                        // default entry focus.
                        pendingDiscoverRestoreOnResume = true
                        onOpenDiscover()
                    },
                    discoverFocusRequester = discoverButtonFocusRequester,
                    showDiscoverButton = uiState.discoverLocation == DiscoverLocation.IN_SEARCH,
                    keyboardController = keyboardController,
                    clearHistoryFocusRequester = if (showRecentSearches) recentClearHistoryFocusRequester else null,
                    isScreenActive = isScreenActive
                )
            }

            if (isDiscoverMode) {
                if (showRecentSearches) {
                    item(key = "recent_searches") {
                        RecentSearchesSection(
                            recentSearches = uiState.recentSearches,
                            onSearchSelected = submitRecentSearch,
                            onClearHistory = {
                                viewModel.onEvent(SearchEvent.ClearRecentSearches)
                            },
                            onRemoveSearch = { query ->
                                viewModel.onEvent(SearchEvent.RemoveRecentSearch(query))
                            },
                            onSectionFocusChanged = { focused -> isRecentSearchSectionFocused = focused },
                            clearHistoryFocusRequester = recentClearHistoryFocusRequester,
                            emptyHistoryFocusRequester = searchFocusRequester,
                            modifier = Modifier.padding(horizontal = 52.dp)
                        )
                    }
                } else {
                    item(key = "search_start") {
                        EmptyScreenState(
                            title = stringResource(R.string.search_start_title),
                            subtitle = stringResource(R.string.search_start_subtitle),
                            icon = Icons.Default.Search
                        )
                    }
                }
            } else {
                // The "press Done to search" hint is gone: search now runs as you type, so the
                // instruction is wrong, and it was re-appearing on every keystroke. Neither the
                // mobile nor the desktop client shows an equivalent message.

                // Live TV fork: the Live TV and On Demand rows, above or below the addon rows as
                // set in Live TV settings (Search & Streams).
                fun androidx.compose.foundation.lazy.LazyListScope.forkSection(kind: String) {
                    when (kind) {
                        "live" -> if (hasLiveTvResults) {
                            item(key = "live_tv_results") {
                                com.nuvio.tv.livetv.ui.LiveTvSearchRow(
                                    results = liveTvResults,
                                    entryFocusRequester = liveTvRowFocusRequester,
                                    upFocusRequester = sectionUp("live"),
                                    posterCardStyle = posterCardStyle
                                )
                            }
                        }
                        "ondemand" -> if (hasOnDemandResults) {
                            item(key = "on_demand_results") {
                                com.nuvio.tv.livetv.ondemand.OnDemandSearchRow(
                                    results = onDemandResults,
                                    entryFocusRequester = onDemandRowFocusRequester,
                                    upFocusRequester = sectionUp("ondemand"),
                                    onOpenDetail = onOpenOnDemand,
                                    onPlay = onPlayOnDemand,
                                    posterCardStyle = posterCardStyle
                                )
                            }
                        }
                    }
                }
                forkBeforeCatalog.forEach { forkSection(it) }

                when {
                    trimmedSubmittedQuery.length < MIN_SEARCH_QUERY_LENGTH && !hasPendingUnsubmittedQuery -> {
                        item {
                            if (showRecentSearches) {
                                RecentSearchesSection(
                                    recentSearches = uiState.recentSearches,
                                    onSearchSelected = submitRecentSearch,
                                    onClearHistory = {
                                        viewModel.onEvent(SearchEvent.ClearRecentSearches)
                                    },
                                    onRemoveSearch = { query ->
                                        viewModel.onEvent(SearchEvent.RemoveRecentSearch(query))
                                    },
                                    onSectionFocusChanged = { focused ->
                                        isRecentSearchSectionFocused = focused
                                    },
                                    clearHistoryFocusRequester = recentClearHistoryFocusRequester,
                                    emptyHistoryFocusRequester = searchFocusRequester,
                                    modifier = Modifier.padding(horizontal = 52.dp)
                                )
                            } else {
                                EmptyScreenState(
                                    title = stringResource(R.string.search_start_title),
                                    subtitle = if (uiState.discoverLocation == DiscoverLocation.OFF) {
                                        stringResource(R.string.search_start_subtitle_no_discover)
                                    } else {
                                        stringResource(R.string.search_start_subtitle)
                                    },
                                    icon = Icons.Default.Search
                                )
                            }
                        }
                    }

                    // Nothing to show yet, either still waiting on the debounce or on the first
                    // responses. Mobile renders skeleton rows for both, so this does too. Unlike
                    // mobile it only applies with an empty screen: mobile swaps results out for
                    // skeletons on every keystroke, which on a remote reads as flicker because each
                    // letter outlasts the debounce, so existing results are kept instead.
                    searchScope.catalog && (hasPendingUnsubmittedQuery || uiState.isSearching) && visibleCatalogRows.isEmpty() -> {
                        items(SEARCH_SKELETON_ROW_COUNT, key = { "search_skeleton_$it" }) { index ->
                            val skeletonRow = remember(index) {
                                com.nuvio.tv.domain.model.CatalogRow(
                                    addonId = "__skeleton",
                                    addonName = "",
                                    addonBaseUrl = "",
                                    catalogId = "skeleton_$index",
                                    catalogName = "",
                                    type = com.nuvio.tv.domain.model.ContentType.MOVIE,
                                    items = (0 until 8).map { i ->
                                        com.nuvio.tv.domain.model.MetaPreview(
                                            id = "__placeholder_skeleton_${index}_$i",
                                            type = com.nuvio.tv.domain.model.ContentType.MOVIE,
                                            name = " ",
                                            poster = com.nuvio.tv.domain.model.PLACEHOLDER_IMAGE_URL,
                                            posterShape = com.nuvio.tv.domain.model.PosterShape.POSTER,
                                            background = null,
                                            logo = null,
                                            description = null,
                                            releaseInfo = " ",
                                            imdbRating = null,
                                            genres = emptyList()
                                        )
                                    },
                                    isLoading = true
                                )
                            }
                            CatalogRowSection(
                                catalogRow = skeletonRow,
                                onItemClick = { _, _, _ -> },
                                posterCardStyle = posterCardStyle,
                                showAddonName = uiState.catalogAddonNameEnabled,
                                modifier = Modifier.padding(bottom = 24.dp)
                            )
                        }
                    }

                    searchScope.catalog && uiState.error != null && uiState.catalogRows.isEmpty() -> {
                        item {
                            ErrorState(
                                message = uiState.error ?: stringResource(R.string.search_error_failed),
                                onRetry = { viewModel.onEvent(SearchEvent.Retry) }
                            )
                        }
                    }

                    // Live TV fork: On Demand is still looking (big providers take a few seconds):
                    // say so, instead of "no results" until its row turns up.
                    (!searchScope.catalog || (!uiState.isSearching && !hasPendingUnsubmittedQuery)) &&
                        visibleCatalogRows.isEmpty() &&
                        liveTvResults.hits.isEmpty() && onDemandResults.items.isEmpty() && onDemandResults.searching -> {
                        item {
                            EmptyScreenState(
                                title = "Still searching…",
                                subtitle = "Looking through your On Demand movies and series",
                                icon = Icons.Default.Search
                            )
                        }
                    }

                    (!searchScope.catalog || (!uiState.isSearching && !hasPendingUnsubmittedQuery)) &&
                        visibleCatalogRows.isEmpty() &&
                        liveTvResults.hits.isEmpty() && onDemandResults.items.isEmpty() -> {
                        item {
                            EmptyScreenState(
                                title = stringResource(R.string.search_no_results_title),
                                subtitle = stringResource(R.string.search_no_results_subtitle),
                                icon = Icons.Default.Search
                            )
                        }
                    }

                    else -> {
                        itemsIndexed(
                            items = visibleCatalogRows,
                            key = { index, item ->
                                "${item.stableKey()}_$index"
                            },
                            contentType = { _, _ -> "catalog_row" }
                        ) { index, catalogRow ->
                            val catalogKey = catalogRow.stableKey()
                            val isPlaceholder = catalogRow.isLoading &&
                                catalogRow.items.firstOrNull()?.id?.startsWith("__placeholder_") == true
                            val hasEnoughForSeeAll = !isPlaceholder && catalogRow.items.size >= 15

                            val listState = searchRowStates.getOrPut(catalogKey) {
                                val saved = viewModel.savedRowScrollPositions[catalogKey]
                                LazyListState(
                                    firstVisibleItemIndex = saved?.first ?: 0,
                                    firstVisibleItemScrollOffset = saved?.second ?: 0
                                )
                            }
                            val rowFocusRequester = searchRowFocusRequesters.getOrPut(catalogKey) { FocusRequester() }
                            val entryFocusRequester = searchRowEntryFocusRequesters.getOrPut(catalogKey) { FocusRequester() }

                            CatalogRowSection(
                                catalogRow = catalogRow,
                                posterCardStyle = posterCardStyle,
                                showSeeAll = hasEnoughForSeeAll,
                                showPosterLabels = uiState.posterLabelsEnabled,
                                showAddonName = uiState.catalogAddonNameEnabled,
                                showCatalogTypeSuffix = uiState.catalogTypeSuffixEnabled,
                                enableRowFocusRestorer = true,
                                rowFocusRequester = rowFocusRequester,
                                entryFocusRequester = entryFocusRequester,
                                // Anchor Up to the field; geometric focus varies with the card.
                                upFocusRequester = if (index == 0) sectionUp("catalog") else null,
                                listState = listState,
                                restorerFocusedIndex = if (restoringSearchFocus.value && catalogKey == viewModel.savedFocusRowKey) {
                                    viewModel.savedFocusItemIndex
                                } else {
                                    searchRowFocusedItemIndex[catalogKey] ?: -1
                                },
                                focusResetToken = if (catalogKey == focusResetRowKey) {
                                    "${uiState.query}#$focusResetCounter"
                                } else {
                                    uiState.query
                                },
                                isItemWatched = { item ->
                                    val isSeries = item.apiType.equals("series", ignoreCase = true) || item.apiType.equals("tv", ignoreCase = true)
                                    if (isSeries) item.id in watchedSeriesIds else item.id in watchedMovieIds
                                },
                                focusedItemIndex = when {
                                    restoringSearchFocus.value && catalogKey == viewModel.savedFocusRowKey ->
                                        viewModel.savedFocusItemIndex
                                    // The remembered card, not item 0. A query change clears
                                    // the map, so a new search still lands on the first item.
                                    focusResults && index == 0 ->
                                        searchRowFocusedItemIndex[catalogKey] ?: 0
                                    else -> -1
                                },
                                onItemFocused = { itemIndex ->
                                    if (focusResults) {
                                        focusResults = false
                                    }
                                    if (restoringSearchFocus.value) {
                                        restoringSearchFocus.value = false
                                        didRestoreSearchFocus.value = true
                                        viewModel.hasSavedSearchFocus = false
                                    }
                                    // User manually navigated to a row — cancel any
                                    // pending auto-focus so it doesn't steal focus later.
                                    pendingFocusMoveToResultsQuery = null
                                    searchRowFocusedItemIndex[catalogKey] = itemIndex
                                    focusedResultItemIndex.intValue = itemIndex
                                    // Prefetch meta for the focused item to warm cache for detail screen.
                                    catalogRow.items.getOrNull(itemIndex)?.let { item ->
                                        viewModel.prefetchMetaOnFocus(item.id, item.rawType)
                                    }
                                    lastFocusedRowKey = catalogKey
                                },
                                onItemClick = { id, type, addonBaseUrl ->
                                    lastFocusedRowKey = catalogKey
                                    saveSearchFocusForDetail(catalogKey)
                                    val clickedItem = catalogRow.items.firstOrNull { it.id == id }
                                    val backdrop = viewModel.getCachedBackdrop(id, type)
                                        ?: clickedItem?.backdropUrl
                                    HeroBackdropState.update(backdrop)
                                    onNavigateToDetail(id, type, addonBaseUrl)
                                },
                                onItemLongPress = { item, addonBaseUrl ->
                                    posterOptionsRowKey = catalogKey
                                    viewModel.posterOptions.show(item, addonBaseUrl)
                                },
                                onSeeAll = {
                                    onNavigateToSeeAll(
                                        catalogRow.catalogId,
                                        catalogRow.addonId,
                                        catalogRow.apiType
                                    )
                                }
                            )
                        }

                        // Results are up but more catalogs are still answering, as on mobile.
                        if (uiState.isSearching || hasPendingUnsubmittedQuery) {
                            item(key = "search_loading_more") {
                                val skeletonRow = remember {
                                    com.nuvio.tv.domain.model.CatalogRow(
                                        addonId = "__skeleton",
                                        addonName = "",
                                        addonBaseUrl = "",
                                        catalogId = "skeleton_more",
                                        catalogName = "",
                                        type = com.nuvio.tv.domain.model.ContentType.MOVIE,
                                        items = (0 until 8).map { i ->
                                            com.nuvio.tv.domain.model.MetaPreview(
                                                id = "__placeholder_skeleton_more_$i",
                                                type = com.nuvio.tv.domain.model.ContentType.MOVIE,
                                                name = " ",
                                                poster = com.nuvio.tv.domain.model.PLACEHOLDER_IMAGE_URL,
                                                posterShape = com.nuvio.tv.domain.model.PosterShape.POSTER,
                                                background = null,
                                                logo = null,
                                                description = null,
                                                releaseInfo = " ",
                                                imdbRating = null,
                                                genres = emptyList()
                                            )
                                        },
                                        isLoading = true
                                    )
                                }
                                CatalogRowSection(
                                    catalogRow = skeletonRow,
                                    onItemClick = { _, _, _ -> },
                                    posterCardStyle = posterCardStyle,
                                    showAddonName = uiState.catalogAddonNameEnabled,
                                    modifier = Modifier.padding(bottom = 24.dp)
                                )
                            }
                        }
                    }
                }
                // Live TV fork: sections set to come after the addon rows.
                forkAfterCatalog.forEach { forkSection(it) }
            }
        }
    }

    val posterOptionsState by viewModel.posterOptions.state.collectAsState()
    com.nuvio.tv.ui.components.posteroptions.PosterOptionsHost(
        calendarBell = true,
        state = posterOptionsState,
        controller = viewModel.posterOptions,
        onNavigateToDetail = { id, type, addonBaseUrl ->
            // Consume it, so a later navigation cannot reuse this row.
            posterOptionsRowKey?.let(saveSearchFocusForDetail)
            posterOptionsRowKey = null
            val clickedItem = uiState.catalogRows
                .flatMap { it.items }
                .firstOrNull { it.id == id }
                ?: uiState.discoverResults.firstOrNull { it.id == id }
            HeroBackdropState.update(clickedItem?.backdropUrl)
            onNavigateToDetail(id, type, addonBaseUrl)
        }
    )
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun RecentSearchesSection(
    recentSearches: List<String>,
    onSearchSelected: (String) -> Unit,
    onClearHistory: () -> Unit,
    onRemoveSearch: (String) -> Unit,
    onSectionFocusChanged: (Boolean) -> Unit,
    clearHistoryFocusRequester: FocusRequester,
    emptyHistoryFocusRequester: FocusRequester,
    modifier: Modifier = Modifier
) {
    val isRtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    val searchFocusRequesters = remember { mutableMapOf<String, FocusRequester>() }
    val removeFocusRequesters = remember { mutableMapOf<String, FocusRequester>() }
    var pendingDownwardFocus by remember { mutableStateOf<Pair<String, String>?>(null) }
    // Downward focus enters the query column. The remove buttons are reached with right.
    val firstSearchFocusRequester = searchFocusRequesters.getOrPut(recentSearches.first()) {
        FocusRequester()
    }
    LaunchedEffect(recentSearches, pendingDownwardFocus) {
        val visibleQueries = recentSearches.toSet()
        searchFocusRequesters.keys.retainAll(visibleQueries)
        removeFocusRequesters.keys.retainAll(visibleQueries)

        val (removedQuery, replacementQuery) = pendingDownwardFocus
            ?: return@LaunchedEffect
        if (removedQuery !in visibleQueries) {
            removeFocusRequesters[replacementQuery]?.let { requester ->
                runCatching { requester.requestFocus() }
            }
            pendingDownwardFocus = null
        }
    }
    Column(
        modifier = modifier
            .fillMaxWidth()
            .focusGroup()
            .onFocusChanged { state ->
                onSectionFocusChanged(state.hasFocus || state.isFocused)
            },
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = stringResource(R.string.search_recent_title),
                style = androidx.tv.material3.MaterialTheme.typography.titleMedium,
                color = NuvioTheme.colors.TextPrimary
            )
            Button(
                onClick = onClearHistory,
                modifier = Modifier
                    .focusRequester(clearHistoryFocusRequester)
                    .focusProperties {
                        down = firstSearchFocusRequester
                    },
                colors = ButtonDefaults.colors(
                    containerColor = NuvioTheme.colors.BackgroundCard,
                    contentColor = NuvioTheme.colors.TextPrimary,
                    focusedContainerColor = NuvioTheme.colors.FocusBackground,
                    focusedContentColor = NuvioTheme.colors.Primary
                ),
                shape = ButtonDefaults.shape(RoundedCornerShape(NuvioTheme.radii.md))
            ) {
                Text(text = stringResource(R.string.search_recent_clear))
            }
        }

        recentSearches.forEachIndexed { index, recentQuery ->
            key(recentQuery) {
                val searchFocusRequester = searchFocusRequesters.getOrPut(recentQuery) {
                    FocusRequester()
                }
                val removeFocusRequester = removeFocusRequesters.getOrPut(recentQuery) {
                    FocusRequester()
                }
                val previousRemoveFocusRequester = if (index == 0) {
                    clearHistoryFocusRequester
                } else {
                    removeFocusRequesters.getOrPut(recentSearches[index - 1]) { FocusRequester() }
                }
                val nextRemoveFocusRequester = recentSearches.getOrNull(index + 1)?.let {
                    removeFocusRequesters.getOrPut(it) { FocusRequester() }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(NuvioTheme.spacing.lg),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    var isSearchFocused by remember(recentQuery) { mutableStateOf(false) }
                    val searchScale by animateFloatAsState(
                        targetValue = if (isSearchFocused) 1.02f else 1f,
                        animationSpec = tween(durationMillis = 140),
                        label = "recentSearchScale"
                    )
                    Button(
                        onClick = { onSearchSelected(recentQuery) },
                        modifier = Modifier
                            .weight(1f)
                            .focusRequester(searchFocusRequester)
                            .focusProperties {
                                if (isRtl) {
                                    left = removeFocusRequester
                                } else {
                                    right = removeFocusRequester
                                }
                            }
                            .onFocusChanged { isSearchFocused = it.isFocused }
                            .graphicsLayer {
                                scaleX = searchScale
                                scaleY = searchScale
                                transformOrigin = TransformOrigin(
                                    pivotFractionX = if (isRtl) 1f else 0f,
                                    pivotFractionY = 0.5f
                                )
                            },
                        colors = ButtonDefaults.colors(
                            containerColor = NuvioTheme.colors.BackgroundCard,
                            contentColor = NuvioTheme.colors.TextPrimary,
                            focusedContainerColor = NuvioTheme.colors.FocusBackground,
                            focusedContentColor = NuvioTheme.colors.Primary
                        ),
                        scale = ButtonDefaults.scale(focusedScale = 1f),
                        shape = ButtonDefaults.shape(RoundedCornerShape(NuvioTheme.radii.md))
                    ) {
                        Text(
                            text = recentQuery,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    var isRemoveFocused by remember(recentQuery) { mutableStateOf(false) }
                    TvIconButton(
                        onClick = {
                            val nextQuery = recentSearches.getOrNull(index + 1)
                            val previousQuery = recentSearches.getOrNull(index - 1)
                            when {
                                nextQuery != null -> {
                                    pendingDownwardFocus = recentQuery to nextQuery
                                }
                                previousQuery != null -> {
                                    runCatching {
                                        removeFocusRequesters.getValue(previousQuery).requestFocus()
                                    }
                                }
                                else -> {
                                    runCatching { emptyHistoryFocusRequester.requestFocus() }
                                }
                            }
                            onRemoveSearch(recentQuery)
                        },
                        modifier = Modifier
                            .focusRequester(removeFocusRequester)
                            .focusProperties {
                                up = previousRemoveFocusRequester
                                down = nextRemoveFocusRequester ?: FocusRequester.Cancel
                                if (isRtl) {
                                    right = searchFocusRequester
                                } else {
                                    left = searchFocusRequester
                                }
                            }
                            .onFocusChanged { isRemoveFocused = it.isFocused }
                            .size(36.dp)
                            .then(
                                if (isRemoveFocused) {
                                    Modifier.border(
                                        width = NuvioTheme.spacing.xxs,
                                        color = NuvioTheme.colors.FocusRing,
                                        shape = RoundedCornerShape(NuvioTheme.radii.md)
                                    )
                                } else {
                                    Modifier
                                }
                            ),
                        colors = TvIconButtonDefaults.colors(
                            containerColor = Color.Transparent,
                            focusedContainerColor = NuvioTheme.colors.FocusBackground,
                            contentColor = NuvioTheme.colors.TextPrimary,
                            focusedContentColor = NuvioTheme.colors.TextPrimary
                        ),
                        scale = TvIconButtonDefaults.scale(focusedScale = 1f),
                        shape = TvIconButtonDefaults.shape(
                            shape = RoundedCornerShape(NuvioTheme.radii.md)
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = stringResource(
                                R.string.cd_remove_recent_search,
                                recentQuery
                            ),
                            modifier = Modifier.size(18.dp),
                            tint = NuvioTheme.colors.TextPrimary
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SearchInputField(
    modifier: Modifier = Modifier,
    query: String,
    canMoveToResults: Boolean,
    voiceFocusRequester: FocusRequester?,
    searchFocusRequester: FocusRequester,
    onSearchFieldFocusChanged: (Boolean) -> Unit,
    onQueryChanged: (String) -> Unit,
    onSubmit: () -> Unit,
    showVoiceSearch: Boolean,
    isVoiceListening: Boolean,
    voiceRmsLevel: Float,
    onVoiceSearch: () -> Unit,
    onMoveToResults: () -> Unit,
    onOpenDiscover: () -> Unit,
    discoverFocusRequester: FocusRequester? = null,
    showDiscoverButton: Boolean,
    keyboardController: androidx.compose.ui.platform.SoftwareKeyboardController?,
    clearHistoryFocusRequester: FocusRequester?,
    isScreenActive: Boolean = true
) {
    var isDiscoverButtonFocused by remember { mutableStateOf(false) }
    var isVoiceButtonFocused by remember { mutableStateOf(false) }
    val isRtl = LocalLayoutDirection.current == LayoutDirection.Rtl

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = NuvioTheme.spacing.xxxl)
            .focusGroup(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (showDiscoverButton) {
            IconButton(
                onClick = onOpenDiscover,
                modifier = Modifier
                    .then(
                        discoverFocusRequester?.let { Modifier.focusRequester(it) } ?: Modifier
                    )
                    .onFocusChanged { isDiscoverButtonFocused = it.isFocused }
                    .size(NuvioTheme.spacing.huge)
                    .border(
                        width = if (isDiscoverButtonFocused) NuvioTheme.spacing.xxs else NuvioTheme.spacing.hairline,
                        color = if (isDiscoverButtonFocused) NuvioTheme.colors.FocusRing else NuvioTheme.colors.Border,
                        shape = RoundedCornerShape(NuvioTheme.radii.md)
                    )
                    .background(
                        color = NuvioTheme.colors.BackgroundCard,
                        shape = RoundedCornerShape(NuvioTheme.radii.md)
                    )
            ) {
                Icon(
                    imageVector = Icons.Default.Explore,
                    contentDescription = stringResource(R.string.cd_open_discover),
                    tint = NuvioTheme.colors.TextPrimary
                )
            }

            Spacer(modifier = Modifier.width(NuvioTheme.spacing.md))
        }

        if (showVoiceSearch) {
            val themeAccent = NuvioTheme.colors.Secondary

            // Pulsating animation (constant rhythm while listening)
            val pulseTransition = rememberInfiniteTransition(label = "voicePulse")
            val pulseScale by pulseTransition.animateFloat(
                initialValue = 1f,
                targetValue = 1.35f,
                animationSpec = infiniteRepeatable(
                    animation = tween(800, easing = LinearEasing),
                    repeatMode = RepeatMode.Restart
                ),
                label = "pulseScale"
            )
            val pulseAlpha by pulseTransition.animateFloat(
                initialValue = 0.5f,
                targetValue = 0f,
                animationSpec = infiniteRepeatable(
                    animation = tween(800, easing = LinearEasing),
                    repeatMode = RepeatMode.Restart
                ),
                label = "pulseAlpha"
            )

            // RMS-based ring — smoothly follows mic input level
            val animatedRms by animateFloatAsState(
                targetValue = if (isVoiceListening) voiceRmsLevel else 0f,
                animationSpec = tween(100),
                label = "rmsRing"
            )

            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.size(72.dp) // extra room for rings
            ) {
                // Layer 1: Pulsating ring (constant rhythm)
                if (isVoiceListening) {
                    Canvas(modifier = Modifier.matchParentSize()) {
                        val radius = (size.minDimension / 2f) * pulseScale
                        drawCircle(
                            color = themeAccent.copy(alpha = pulseAlpha * 0.4f),
                            radius = radius
                        )
                    }
                }

                // Layer 2: RMS level ring (voice-reactive)
                if (isVoiceListening && animatedRms > 0.01f) {
                    Canvas(modifier = Modifier.matchParentSize()) {
                        val rmsRadius = (size.minDimension / 2f) * (1f + animatedRms * 0.35f)
                        drawCircle(
                            color = themeAccent.copy(alpha = 0.25f + animatedRms * 0.25f),
                            radius = rmsRadius,
                            style = androidx.compose.ui.graphics.drawscope.Stroke(
                                width = 2.5f + animatedRms * 3f
                            )
                        )
                    }
                }

                // Layer 3: Actual button
                IconButton(
                    onClick = onVoiceSearch,
                    modifier = Modifier
                        .then(
                            if (voiceFocusRequester != null) {
                                Modifier.focusRequester(voiceFocusRequester)
                            } else {
                                Modifier
                            }
                        )
                        .onFocusChanged { isVoiceButtonFocused = it.isFocused }
                        .size(NuvioTheme.spacing.huge)
                        .border(
                            width = if (isVoiceButtonFocused || isVoiceListening) NuvioTheme.spacing.xxs else NuvioTheme.spacing.hairline,
                            color = if (isVoiceListening) themeAccent else if (isVoiceButtonFocused) NuvioTheme.colors.FocusRing else NuvioTheme.colors.Border,
                            shape = RoundedCornerShape(NuvioTheme.radii.md)
                        )
                        .background(
                            color = if (isVoiceListening) themeAccent.copy(alpha = 0.15f) else NuvioTheme.colors.BackgroundCard,
                            shape = RoundedCornerShape(NuvioTheme.radii.md)
                        )
                ) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = stringResource(R.string.cd_voice_search),
                        tint = if (isVoiceListening) themeAccent else NuvioTheme.colors.TextPrimary
                    )
                }
            }

            Spacer(modifier = Modifier.width(NuvioTheme.spacing.md))
        }

        OutlinedTextField(
            value = query,
            onValueChange = onQueryChanged,
            modifier = Modifier
                .weight(1f)
                .focusRequester(searchFocusRequester)
                .focusProperties {
                    canFocus = isScreenActive
                }
                .onFocusChanged { focusState ->
                    onSearchFieldFocusChanged(focusState.isFocused)
                }
                .onPreviewKeyEvent { keyEvent ->
                    when (keyEvent.nativeKeyEvent.keyCode) {
                        KeyEvent.KEYCODE_ENTER,
                        KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                            if (keyEvent.nativeKeyEvent.action == KeyEvent.ACTION_DOWN) {
                                onSubmit()
                            }
                            return@onPreviewKeyEvent true
                        }

                        KeyEvent.KEYCODE_DPAD_DOWN -> {
                            if (canMoveToResults) {
                                if (keyEvent.nativeKeyEvent.action == KeyEvent.ACTION_DOWN) {
                                    keyboardController?.hide()
                                    onMoveToResults()
                                }
                                return@onPreviewKeyEvent true
                            }
                        }

                        else -> {
                            val clearHistoryKey = RtlKeyUtils.getClearHistoryDpadKey(isRtl)
                            if (keyEvent.nativeKeyEvent.keyCode == clearHistoryKey) {
                                if (clearHistoryFocusRequester != null) {
                                    if (keyEvent.nativeKeyEvent.action == KeyEvent.ACTION_DOWN) {
                                        keyboardController?.hide()
                                        runCatching { clearHistoryFocusRequester.requestFocus() }
                                    }
                                    return@onPreviewKeyEvent true
                                }
                            }
                        }
                    }
                    false
                },
            keyboardOptions = KeyboardOptions.Default.copy(
                 imeAction = ImeAction.Done,
                 autoCorrectEnabled = false
             ),
            keyboardActions = KeyboardActions(
                onDone = {
                    onSubmit()
                    keyboardController?.hide()
                }
            ),
            singleLine = true,
            shape = RoundedCornerShape(NuvioTheme.radii.md),
            placeholder = {
                Text(
                    text = stringResource(R.string.search_placeholder),
                    color = NuvioTheme.colors.TextTertiary
                )
            },
            textStyle = TextStyle(
                textDirection = TextDirection.Content
            ),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = NuvioTheme.colors.BackgroundCard,
                unfocusedContainerColor = NuvioTheme.colors.BackgroundCard,
                focusedIndicatorColor = NuvioTheme.colors.FocusRing,
                unfocusedIndicatorColor = NuvioTheme.colors.Border,
                focusedTextColor = NuvioTheme.colors.TextPrimary,
                unfocusedTextColor = NuvioTheme.colors.TextPrimary,
                cursorColor = NuvioTheme.colors.FocusRing
            )
        )

        // Clear button, requested in review. Placed beside the field rather than as a trailing
        // icon so it is reachable with the D-pad, matching the voice button's treatment.
        if (query.isNotEmpty()) {
            var isClearButtonFocused by remember { mutableStateOf(false) }
            Spacer(modifier = Modifier.width(NuvioTheme.spacing.md))
            IconButton(
                onClick = {
                    // Clearing drops this button from the row, so hand focus back first.
                    runCatching { searchFocusRequester.requestFocus() }
                    onQueryChanged("")
                },
                modifier = Modifier
                    .onFocusChanged { isClearButtonFocused = it.isFocused }
                    .size(NuvioTheme.spacing.huge)
                    .border(
                        width = if (isClearButtonFocused) NuvioTheme.spacing.xxs else NuvioTheme.spacing.hairline,
                        color = if (isClearButtonFocused) NuvioTheme.colors.FocusRing else NuvioTheme.colors.Border,
                        shape = RoundedCornerShape(NuvioTheme.radii.md)
                    )
                    .background(
                        color = NuvioTheme.colors.BackgroundCard,
                        shape = RoundedCornerShape(NuvioTheme.radii.md)
                    )
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = stringResource(R.string.cd_clear_search),
                    tint = NuvioTheme.colors.TextPrimary
                )
            }
        }
    }
}
