package com.nuvio.tv.ui.screens.home

import android.content.Context
import android.os.SystemClock
import androidx.compose.runtime.mutableStateMapOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nuvio.tv.LocaleCache
import com.nuvio.tv.core.player.StreamAutoPlayPolicy
import com.nuvio.tv.core.recommendations.TvRecommendationManager
import com.nuvio.tv.core.tmdb.MetaPreviewEnricher
import com.nuvio.tv.core.tmdb.TmdbMetadataService
import com.nuvio.tv.core.tmdb.TmdbService
import com.nuvio.tv.data.local.AuthSessionNoticeDataStore
import com.nuvio.tv.data.local.CollectionsDataStore
import com.nuvio.tv.data.local.LayoutPreferenceDataStore
import com.nuvio.tv.data.local.PlayerSettingsDataStore
import com.nuvio.tv.data.local.StartupAuthNotice
import com.nuvio.tv.data.local.MDBListSettingsDataStore
import com.nuvio.tv.data.local.TmdbSettingsDataStore
import com.nuvio.tv.data.local.TraktSettingsDataStore
import com.nuvio.tv.data.local.ContinueWatchingEnrichmentCache
import com.nuvio.tv.data.mediaserver.ServerCatalog
import com.nuvio.tv.data.trailer.TrailerService
import com.nuvio.tv.domain.model.Addon
import com.nuvio.tv.domain.model.CatalogDescriptor
import com.nuvio.tv.domain.model.CatalogRow
import com.nuvio.tv.domain.model.Collection
import com.nuvio.tv.domain.model.ContinueWatchingSortMode
import com.nuvio.tv.domain.model.LibraryEntryInput
import com.nuvio.tv.domain.model.ListMembershipChanges
import com.nuvio.tv.domain.model.Meta
import com.nuvio.tv.domain.model.MetaPreview
import com.nuvio.tv.data.repository.MDBListRepository
import com.nuvio.tv.domain.model.MDBListSettings
import com.nuvio.tv.domain.model.TmdbSettings
import com.nuvio.tv.domain.repository.AddonRepository
import com.nuvio.tv.domain.repository.CatalogRepository
import com.nuvio.tv.domain.repository.LibraryRepository
import com.nuvio.tv.domain.repository.MetaRepository
import com.nuvio.tv.domain.repository.WatchProgressRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import java.util.Collections
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject

@OptIn(kotlinx.coroutines.FlowPreview::class)
@HiltViewModel
class HomeViewModel @Inject constructor(
    @ApplicationContext internal val appContext: Context,
    internal val addonRepository: AddonRepository,
    internal val startupSyncService: com.nuvio.tv.core.sync.StartupSyncService,
    internal val catalogRepository: CatalogRepository,
    internal val watchProgressRepository: WatchProgressRepository,
    internal val libraryRepository: LibraryRepository,
    internal val metaRepository: MetaRepository,
    internal val episodeShuffleStore: com.nuvio.tv.data.local.EpisodeShuffleStore,
    internal val episodeShuffle: com.nuvio.tv.domain.model.EpisodeShuffle,
    internal val collectionsDataStore: CollectionsDataStore,
    internal val layoutPreferenceDataStore: LayoutPreferenceDataStore,
    internal val playerSettingsDataStore: PlayerSettingsDataStore,
    internal val tmdbSettingsDataStore: TmdbSettingsDataStore,
    internal val mdbListSettingsDataStore: MDBListSettingsDataStore,
    internal val traktSettingsDataStore: TraktSettingsDataStore,
    internal val authSessionNoticeDataStore: AuthSessionNoticeDataStore,
    internal val tmdbService: TmdbService,
    internal val tmdbMetadataService: TmdbMetadataService,
    internal val mdbListRepository: MDBListRepository,
    internal val imdbEpisodeRatingsRepository: com.nuvio.tv.data.repository.ImdbEpisodeRatingsRepository,
    internal val trailerService: TrailerService,
    internal val watchedSeriesStateHolder: com.nuvio.tv.data.local.WatchedSeriesStateHolder,
    internal val cwEnrichmentCache: ContinueWatchingEnrichmentCache,
    internal val profileManager: com.nuvio.tv.core.profile.ProfileManager,
    internal val tvRecommendationManager: TvRecommendationManager,
    internal val serverCatalog: ServerCatalog,
    internal val metaPreviewEnricher: MetaPreviewEnricher = MetaPreviewEnricher(
        tmdbService,
        tmdbMetadataService,
        mdbListRepository
    )
) : ViewModel() {
    companion object {
        internal const val TAG = "HomeViewModel"
        internal const val STARTUP_GRACE_PERIOD_MS = 1_500L
        internal const val CONTINUE_WATCHING_ENRICHMENT_GRACE_PERIOD_MS = 1_000L
        private const val CONTINUE_WATCHING_WINDOW_MS = 30L * 24 * 60 * 60 * 1000
        private const val MAX_RECENT_PROGRESS_ITEMS = 300
        private const val MAX_NEXT_UP_LOOKUPS = 24
        private const val MAX_NEXT_UP_CONCURRENCY = 4
        private const val MAX_CATALOG_LOAD_CONCURRENCY = 3

        /** How long a home catalog is left alone before a return to Home re-requests it. */
        private const val HOME_CATALOG_REFRESH_TTL_MS = 15L * 60L * 1000L
        internal const val EXTERNAL_META_PREFETCH_FOCUS_DEBOUNCE_MS = 220L
        internal const val EXTERNAL_META_PREFETCH_ADJACENT_DEBOUNCE_MS = 120L
        private const val MAX_ENRICHMENT_CACHE_SIZE = 64
        private const val MAX_PREFETCH_CACHE_SIZE = 64
        private const val MAX_CW_CACHE_SIZE = 64

        private fun <K, V> createLruMap(maxSize: Int): MutableMap<K, V> {
            val lru = object : LinkedHashMap<K, V>(maxSize + 4, 0.75f, true) {
                override fun removeEldestEntry(eldest: MutableMap.MutableEntry<K, V>?): Boolean =
                    size > maxSize
            }
            return java.util.Collections.synchronizedMap(lru)
        }
    }

    internal val _uiState = MutableStateFlow(HomeUiState())
    internal val shuffleHomeRefresh = MutableStateFlow(HomeShuffleRefresh())
    val uiState: StateFlow<HomeUiState> by lazy { createShuffleHomeState() }

    fun beginShuffleHomeVisit() {
        shuffleHomeRefresh.update { it.copy(visit = it.visit + 1) }
    }

    internal val _modernHomePresentation = MutableStateFlow(ModernHomePresentationState())
    val modernHomePresentation: StateFlow<ModernHomePresentationState> = _modernHomePresentation.asStateFlow()

    internal val _movieWatchedStatus = MutableStateFlow<Map<String, Boolean>>(emptyMap())
    val movieWatchedStatus: StateFlow<Map<String, Boolean>> = _movieWatchedStatus.asStateFlow()

    // Pending batch of watched status updates — debounced before emission.
    internal val _pendingWatchedBatch = MutableStateFlow<Map<String, Boolean>>(emptyMap())
    /** True once the CW pipeline has completed its first emission (items or empty). */
    internal val _initialCwResolved = MutableStateFlow(false)
    val initialCwResolved: StateFlow<Boolean> = _initialCwResolved.asStateFlow()
    val effectiveAutoplayEnabled = playerSettingsDataStore.playerSettings
        .map(StreamAutoPlayPolicy::isEffectivelyEnabled)
        .distinctUntilChanged()
    internal val _fullCatalogRows = MutableStateFlow<List<CatalogRow>>(emptyList())
    val fullCatalogRows: StateFlow<List<CatalogRow>> = _fullCatalogRows.asStateFlow()

    private val _focusState = MutableStateFlow(HomeScreenFocusState())
    val focusState: StateFlow<HomeScreenFocusState> = _focusState.asStateFlow()

    private val _gridFocusState = MutableStateFlow(HomeScreenFocusState())
    val gridFocusState: StateFlow<HomeScreenFocusState> = _gridFocusState.asStateFlow()

    private val _scrollToTopTrigger = MutableStateFlow(0)
    val scrollToTopTrigger: StateFlow<Int> = _scrollToTopTrigger.asStateFlow()

    internal val _currentLocaleTag = MutableStateFlow(LocaleCache.localeTag)

    fun notifyLocaleChanged() {
        val tag = LocaleCache.localeTag
        if (_currentLocaleTag.value != tag) {
            _currentLocaleTag.value = tag
        }
    }

    fun requestScrollToTop() {
        clearFocusState()
        _gridFocusState.value = HomeScreenFocusState()
        _scrollToTopTrigger.value++
    }

    internal val _loadingCatalogs = MutableStateFlow<Set<String>>(emptySet())
    val loadingCatalogs: StateFlow<Set<String>> = _loadingCatalogs.asStateFlow()

    internal val _enrichingItemId = MutableStateFlow<String?>(null)
    val enrichingItemId: StateFlow<String?> = _enrichingItemId.asStateFlow()
    internal fun setEnrichingItemId(id: String?) { _enrichingItemId.value = id }

    internal val _lastEnrichedPreview = MutableStateFlow<MetaPreview?>(null)
    val lastEnrichedPreview: StateFlow<MetaPreview?> = _lastEnrichedPreview.asStateFlow()

    internal val _enrichedPreviews = MutableStateFlow<Map<String, MetaPreview>>(emptyMap())
    val enrichedPreviews: StateFlow<Map<String, MetaPreview>> = _enrichedPreviews.asStateFlow()

    internal fun addEnrichedPreview(id: String, preview: MetaPreview) {
        _enrichedPreviews.update { current ->
            val updated = current + (id to preview)
            if (updated.size <= MAX_ENRICHMENT_CACHE_SIZE) updated
            else LinkedHashMap(updated).apply { while (size > MAX_ENRICHMENT_CACHE_SIZE) remove(keys.first()) }
        }
    }

    /** Items for which enrichment was attempted but produced no enriched data. */
    internal val _failedEnrichmentIds = MutableStateFlow<Set<String>>(emptySet())
    val failedEnrichmentIds: StateFlow<Set<String>> = _failedEnrichmentIds.asStateFlow()

    /**
     * Bounded like the enrichment and prefetch caches beside it. This set is only a hint for the
     * hero, telling it to stop waiting and render catalog data, so evicting the oldest entry costs
     * at most one frame of the loading state the next time that item is focused.
     *
     * Insertion order is part of the contract even though the type is a plain Set: eviction drops
     * the oldest entry, and both this and clearEnrichmentFailure preserve order.
     */
    internal fun markEnrichmentFailed(id: String) {
        _failedEnrichmentIds.update { current ->
            if (id in current) return@update current
            val updated = LinkedHashSet(current).apply { add(id) }
            while (updated.size > MAX_ENRICHMENT_CACHE_SIZE) {
                updated.remove(updated.first())
            }
            updated
        }
    }

    /** Enrichment succeeded after a previous failure, so the item is no longer a failed one. */
    internal fun clearEnrichmentFailure(id: String) {
        _failedEnrichmentIds.update { current -> if (id in current) current - id else current }
    }

    /** Drops every failure marker, for the resets that clear the caches beside this one. */
    internal fun clearEnrichmentFailures() {
        _failedEnrichmentIds.value = emptySet()
    }

    internal val catalogStateLock = Any()
    internal val catalogsMap = linkedMapOf<String, CatalogRow>()
    internal val catalogItemKeyIndex = mutableMapOf<String, MutableSet<String>>()
    internal val catalogOrder = mutableListOf<String>()
    internal var addonsCache: List<Addon> = emptyList()
    internal var collectionsCache: List<Collection> = emptyList()
    internal var homeCatalogOrderKeys: List<String> = emptyList()
    internal var disabledHomeCatalogKeys: Set<String> = emptySet()
    internal var followAddonsOrderEnabled: Boolean = false
    internal var customCatalogTitles: Map<String, String> = emptyMap()
    internal var currentHeroCatalogKeys: List<String> = emptyList()
    internal var catalogUpdateJob: Job? = null
    internal var hasRenderedFirstCatalog = false
    internal val catalogLoadSemaphore = Semaphore(MAX_CATALOG_LOAD_CONCURRENCY)
    internal var pendingCatalogLoads = 0
    internal val activeCatalogLoadJobs = mutableSetOf<Job>()
    internal var activeCatalogLoadSignature: String? = null
    internal var catalogLoadGeneration: Long = 0L
    internal var catalogsLoadInProgress: Boolean = false
    internal data class TruncatedRowCacheEntry(
        val sourceRow: CatalogRow,
        val truncatedRow: CatalogRow
    )
    internal val truncatedRowCache = mutableMapOf<String, TruncatedRowCacheEntry>()
    internal val trailerPreviewLoadingIds = mutableSetOf<String>()
    internal val trailerPreviewNegativeCache = mutableSetOf<String>()
    internal val trailerPreviewUrlsState = mutableStateMapOf<String, String>()
    internal val trailerPreviewAudioUrlsState = mutableStateMapOf<String, String>()
    internal var activeTrailerPreviewItemId: String? = null
    internal var trailerPreviewRequestVersion: Long = 0L
    internal var trailerPreviewJob: Job? = null
    internal var currentTmdbSettings: TmdbSettings = TmdbSettings()
    internal var currentMdbListSettings: MDBListSettings = MDBListSettings()
    internal var heroEnrichmentJob: Job? = null
    internal var lastHeroEnrichmentSignature: String? = null
    internal var lastHeroEnrichedItems: List<MetaPreview> = emptyList()
    internal var heroItemOrder: List<String> = emptyList()
    internal val modernCarouselRowBuildCache = ModernCarouselRowBuildCache()
    internal val prefetchedExternalMetaIds: MutableSet<String> = Collections.newSetFromMap(createLruMap(MAX_PREFETCH_CACHE_SIZE))
    internal val backgroundMetaPrefetchedIds: MutableSet<String> = Collections.newSetFromMap(createLruMap(MAX_PREFETCH_CACHE_SIZE))
    internal val externalMetaPrefetchInFlightIds: MutableSet<String> = ConcurrentHashMap.newKeySet()
    internal var externalMetaPrefetchJob: Job? = null
    internal var pendingExternalMetaPrefetchItemId: String? = null
    internal val prefetchedTmdbIds: MutableSet<String> = Collections.newSetFromMap(createLruMap(MAX_PREFETCH_CACHE_SIZE))

    /** Items an enrichment merge was applied for. */
    internal val enrichmentMergedIds: MutableSet<String> = Collections.newSetFromMap(createLruMap(MAX_PREFETCH_CACHE_SIZE))

    internal val mdbBatchNegativeIds: MutableSet<String> = ConcurrentHashMap.newKeySet()
    internal var mdbBatchRowFocusJob: Job? = null
    @Volatile internal var mdbBatchHasFired: Boolean = false
    internal val cwMetaCache: MutableMap<String, CwMetaSummary?> = createLruMap(MAX_CW_CACHE_SIZE)
    internal val cwMetaNegativeCacheTimestamps: MutableMap<String, Long> = createLruMap(MAX_CW_CACHE_SIZE)
    /** Ultra-light cache for badge evaluation: contentId → set of aired (season, episode) pairs. */
    internal val cwBadgeEpisodeCache: MutableMap<String, Set<Pair<Int, Int>>?> = createLruMap(MAX_CW_CACHE_SIZE)
    /** Per-series earliest upcoming season release date (epochMs) for smart TTL scheduling. */
    internal val cwBadgeNextSeasonMs: MutableMap<String, Long> = createLruMap(MAX_CW_CACHE_SIZE)
    /** Snapshot of watchedShowEpisodes keys from the last badge evaluation cycle. */
    @Volatile
    internal var cwLastBadgeEpisodeKeys: Set<String> = emptySet()
    /** Cached show ID siblings from the last badge evaluation cycle (for anime ID expansion). */
    @Volatile
    internal var cwLastShowIdSiblings: Map<String, Set<String>> = emptyMap()
    internal val cwTmdbIdCache: MutableMap<String, String?> = createLruMap(MAX_CW_CACHE_SIZE)
    internal val cwNextUpResolutionCache = Collections.synchronizedMap(mutableMapOf<String, NextUpResolution?>())
    internal val cwNextUpNegativeCacheTimestamps = ConcurrentHashMap<String, Long>()
    internal val discoveredOlderNextUpItems = Collections.synchronizedList(mutableListOf<ContinueWatchingItem.NextUp>())
    internal val cwLastProcessedNextUpContentIds: MutableSet<String> = ConcurrentHashMap.newKeySet()
    internal val cwProcessedOlderSeedContentIds: MutableSet<String> = ConcurrentHashMap.newKeySet()
    internal val cwEnrichedNextUpOverlay = ConcurrentHashMap<String, NextUpInfo>()
    /** In-memory cache of enriched InProgress items per contentId+episode key. */
    internal val cwEnrichedInProgressOverlay = ConcurrentHashMap<String, ContinueWatchingItem.InProgress>()
    /** Bumped to force the CW pipeline to re-run (e.g. after cache clear). */
    internal val cwPipelineRefreshTrigger = kotlinx.coroutines.flow.MutableStateFlow(0)
    /** Tracks the active CW pipeline coroutine so it can be cancelled on profile switch. */
    internal var cwPipelineJob: Job? = null
    internal val fullyWatchedSeriesIds get() = watchedSeriesStateHolder
    internal var tmdbEnrichFocusJob: Job? = null
    internal var pendingTmdbEnrichItemId: String? = null
    /** Item that was focused during startup grace period — will be enriched once grace ends. */
    internal var deferredEnrichItem: MetaPreview? = null
    internal var adjacentItemPrefetchJob: Job? = null
    internal var pendingAdjacentPrefetchItemId: String? = null
    internal val movieWatchedObserverJobs = mutableMapOf<String, Job>()
    internal var movieWatchedBatchJob: Job? = null
    internal var lastMovieWatchedItemKeys: Set<String> = emptySet()
    internal var seriesWatchedObserverJob: Job? = null
    internal var libraryTabsObserverJob: Job? = null
    internal var activePosterListPickerInput: LibraryEntryInput? = null
    internal var pendingPosterListPickerChanges: ListMembershipChanges? = null
    @Volatile
    internal var externalMetaPrefetchEnabled: Boolean = false
    @Volatile
    internal var continueWatchingSortMode: ContinueWatchingSortMode = ContinueWatchingSortMode.DEFAULT
    internal val startupStartedAtMs: Long = SystemClock.elapsedRealtime()
    @Volatile
    internal var startupGracePeriodActive: Boolean = true
    internal var startupAuthNoticeJob: Job? = null

    // Lazy catalog loading
    internal val eagerCatalogLoadCount: Int = 4
    internal val lazyLoadRequestedKeys: MutableSet<String> = ConcurrentHashMap.newKeySet()
    internal val pendingLazyCatalogs = linkedMapOf<String, Pair<Addon, CatalogDescriptor>>()
    /** All placeholder descriptors for homeRow construction. */
    internal data class PlaceholderDescriptor(
        val catalogKey: String,
        val addonId: String,
        val addonName: String,
        val addonBaseUrl: String,
        val catalogId: String,
        val catalogName: String,
        val apiType: String,
        val displayTitle: String
    )
    internal val placeholderDescriptors = mutableListOf<PlaceholderDescriptor>()
    val trailerPreviewUrls: Map<String, String>
        get() = trailerPreviewUrlsState
    val trailerPreviewAudioUrls: Map<String, String>
        get() = trailerPreviewAudioUrlsState

    init {
        // Accumulates individual watched status changes and flushes them as a single
        // update after 150ms of inactivity, preventing N separate recompositions.
        viewModelScope.launch {
            _pendingWatchedBatch
                .debounce(150L)
                .collect { batch ->
                    if (batch.isNotEmpty()) {
                        val snapshot = _pendingWatchedBatch.value
                        _pendingWatchedBatch.value = emptyMap()
                        if (snapshot.isNotEmpty()) {
                            _movieWatchedStatus.update { current -> current + snapshot }
                        }
                    }
                }
        }

        observeStartupAuthNotice()
        // Live TV fork: the Calendar's cards changed (a new episode is out, a bell rung): put
        // them in again without waiting for Continue Watching's next update.
        viewModelScope.launch {
            com.nuvio.tv.livetv.calendar.CalendarHomeFeed.version.collect {
                _uiState.update { st ->
                    val (main, up) = com.nuvio.tv.livetv.calendar.CalendarHomeFeed.apply(st.continueWatchingItems, st.upcomingItems)
                    if (main == st.continueWatchingItems && up == st.upcomingItems) st
                    else st.copy(continueWatchingItems = main, upcomingItems = up)
                }
            }
        }
        viewModelScope.launch {
            profileManager.activeProfileReady.first { it }
            observeLayoutPreferences()
            observeModernHomePresentation()
            loadContinueWatching()
            watchedSeriesStateHolder.loadFromDisk()
            observeExternalMetaPrefetchPreference()
            observeContinueWatchingSortMode()
            loadHomeCatalogOrderPreference()
            loadFollowAddonsOrder()
            loadDisabledHomeCatalogPreference()
            loadCustomCatalogTitles()
            observeLibraryState()
            observeTmdbSettings()
            observeMdbListSettings()
            observeBlurUnwatchedEpisodes()
            observeProgressSourceChanges()
            observeCollections()
            observeInstalledAddons()
            observeManualAddonRefresh()

            // Clear CW state when profile changes so items don't leak between profiles.
            var previousProfileId = profileManager.activeProfileId.value
            profileManager.activeProfileId.collect { newId ->
                if (newId != previousProfileId) {
                    previousProfileId = newId
                    // Cancel old pipeline — prevents racing writes from stale coroutines.
                    cwPipelineJob?.cancel()
                    cwPipelineJob = null
                    // Clear all in-memory CW caches so data from the previous
                    // profile doesn't leak into the new one.
                    cwMetaCache.clear()
                    cwMetaNegativeCacheTimestamps.clear()
                    cwBadgeEpisodeCache.clear()
                    cwBadgeNextSeasonMs.clear()
                    cwTmdbIdCache.clear()
                    cwNextUpResolutionCache.clear()
                    cwNextUpNegativeCacheTimestamps.clear()
                    discoveredOlderNextUpItems.clear()
                    cwLastProcessedNextUpContentIds.clear()
                    cwProcessedOlderSeedContentIds.clear()
                    cwEnrichedNextUpOverlay.clear()
                    cwEnrichedInProgressOverlay.clear()
                    cwLastBadgeEpisodeKeys = emptySet()
                    cwLastShowIdSiblings = emptyMap()
                    _uiState.update {
                        it.copy(layoutPreferencesReady = false, continueWatchingItems = emptyList())
                    }
                    clearFocusState()
                    _gridFocusState.value = HomeScreenFocusState()
                    // Reset so the new profile's pipeline signals first completion correctly.
                    _initialCwResolved.value = false
                    loadContinueWatching()
                    // Clear watched badges so they don't leak between profiles.
                    watchedSeriesStateHolder.clearInMemory()
                    watchedSeriesStateHolder.loadFromDisk(profileId = newId)
                    _movieWatchedStatus.value = emptyMap()
                    _pendingWatchedBatch.value = emptyMap()
                    _uiState.update { it.copy(movieWatchedStatus = emptyMap()) }
                }
            }
        }
        viewModelScope.launch {
            delay(STARTUP_GRACE_PERIOD_MS)
            startupGracePeriodActive = false
            // Trigger enrichment for the initial focused item once grace ends.
            deferredEnrichItem?.let { item ->
                deferredEnrichItem = null
                onItemFocusPipeline(item)
            }
        }

        // Observe manual cache clear from Advanced settings.
        viewModelScope.launch {
            var lastSeen = cwEnrichmentCache.cacheCleared.value
            cwEnrichmentCache.cacheCleared.collect { version ->
                if (version != lastSeen) {
                    lastSeen = version
                    clearAllCwInMemoryCaches()
                }
            }
        }
    }

    private fun clearAllCwInMemoryCaches() {
        cwMetaCache.clear()
        cwMetaNegativeCacheTimestamps.clear()
        cwBadgeEpisodeCache.clear()
        cwBadgeNextSeasonMs.clear()
        cwTmdbIdCache.clear()
        cwNextUpResolutionCache.clear()
        cwNextUpNegativeCacheTimestamps.clear()
        discoveredOlderNextUpItems.clear()
        cwLastProcessedNextUpContentIds.clear()
        cwProcessedOlderSeedContentIds.clear()
        cwEnrichedNextUpOverlay.clear()
        cwEnrichedInProgressOverlay.clear()
        cwLastBadgeEpisodeKeys = emptySet()
        cwLastShowIdSiblings = emptyMap()
        watchedSeriesStateHolder.clearValidationState()
        _uiState.update { it.copy(continueWatchingItems = emptyList(), upcomingItems = emptyList()) }
        // Bump trigger so the pipeline's collectLatest restarts with fresh state.
        cwPipelineRefreshTrigger.value++
    }

    internal fun remainingStartupGraceMs(nowMs: Long = SystemClock.elapsedRealtime()): Long {
        if (!startupGracePeriodActive) return 0L
        return (STARTUP_GRACE_PERIOD_MS - (nowMs - startupStartedAtMs)).coerceAtLeast(0L)
    }

    internal fun remainingContinueWatchingEnrichmentGraceMs(
        nowMs: Long = SystemClock.elapsedRealtime()
    ): Long {
        return (CONTINUE_WATCHING_ENRICHMENT_GRACE_PERIOD_MS - (nowMs - startupStartedAtMs))
            .coerceAtLeast(0L)
    }

    private fun observeLayoutPreferences() = observeLayoutPreferencesPipeline()

    private fun observeModernHomePresentation() = observeModernHomePresentationPipeline()

    private fun observeExternalMetaPrefetchPreference() = observeExternalMetaPrefetchPreferencePipeline()

    private fun observeContinueWatchingSortMode() {
        viewModelScope.launch {
            var initial = true
            layoutPreferenceDataStore.continueWatchingSortMode
                .distinctUntilChanged()
                .collect { mode ->
                    continueWatchingSortMode = mode
                    if (initial) {
                        initial = false
                        return@collect
                    }
                    // Clear caches so the new sort is applied immediately on next pipeline run
                    clearAllCwInMemoryCaches()
                }
        }
    }

    private fun observeBlurUnwatchedEpisodes() {
        viewModelScope.launch {
            layoutPreferenceDataStore.blurContinueWatchingNextUp
                .distinctUntilChanged()
                .collect { enabled ->
                    _uiState.update { it.copy(blurUnwatchedEpisodes = enabled) }
                }
        }
        viewModelScope.launch {
            layoutPreferenceDataStore.useEpisodeThumbnailsInCw
                .distinctUntilChanged()
                .collect { enabled ->
                    _uiState.update { it.copy(useEpisodeThumbnailsInCw = enabled) }
                }
        }
        viewModelScope.launch {
            layoutPreferenceDataStore.continueWatchingEnabled
                .distinctUntilChanged()
                .collect { enabled ->
                    _uiState.update { it.copy(continueWatchingEnabled = enabled) }
                }
        }
        viewModelScope.launch {
            layoutPreferenceDataStore.continueWatchingCardStyle
                .distinctUntilChanged()
                .collect { style ->
                    _uiState.update { it.copy(continueWatchingCardStyle = style) }
                }
        }
        viewModelScope.launch {
            var initialPattern = true
            layoutPreferenceDataStore.customPosterUrlPattern
                .distinctUntilChanged()
                .collect { pattern ->
                    _uiState.update { it.copy(customPosterUrlPattern = pattern) }
                    if (initialPattern) {
                        initialPattern = false
                    } else {
                        refreshVisibleCatalogsPipeline(forceReplace = true)
                    }
                }
        }
        viewModelScope.launch {
            var initialScreens = true
            layoutPreferenceDataStore.customPosterEnabledScreens
                .distinctUntilChanged()
                .collect { screens ->
                    _uiState.update { it.copy(customPosterEnabledScreens = screens) }
                    if (initialScreens) {
                        initialScreens = false
                    } else {
                        refreshVisibleCatalogsPipeline(forceReplace = true)
                    }
                }
        }
        // When "next up from furthest episode" changes, clear CW caches and retrigger pipeline
        viewModelScope.launch {
            var initial = true
            layoutPreferenceDataStore.nextUpFromFurthestEpisode
                .collect {
                    if (initial) {
                        initial = false
                        return@collect
                    }
                    clearAllCwInMemoryCaches()
                }
        }
        // Episode artwork is chosen while enriching, so cached items must be rebuilt when the setting changes.
        viewModelScope.launch {
            var initial = true
            layoutPreferenceDataStore.useEpisodeThumbnailsInCw
                .distinctUntilChanged()
                .collect {
                    if (initial) {
                        initial = false
                        return@collect
                    }
                    clearAllCwInMemoryCaches()
                }
        }
    }

    fun requestTrailerPreview(item: MetaPreview) = requestTrailerPreviewPipeline(item)

    fun requestTrailerPreview(
        itemId: String,
        title: String,
        releaseInfo: String?,
        apiType: String
    ) = requestTrailerPreviewPipeline(
        itemId = itemId,
        title = title,
        releaseInfo = releaseInfo,
        apiType = apiType
    )

    fun onItemFocus(item: MetaPreview) = onItemFocusPipeline(item)

    fun preloadAdjacentItem(item: MetaPreview) = preloadAdjacentItemPipeline(item)

    private fun loadHomeCatalogOrderPreference() = loadHomeCatalogOrderPreferencePipeline()

    private fun loadFollowAddonsOrder() = loadFollowAddonsOrderPipeline()

    private fun loadDisabledHomeCatalogPreference() = loadDisabledHomeCatalogPreferencePipeline()

    private fun loadCustomCatalogTitles() = loadCustomCatalogTitlesPipeline()

    private fun observeTmdbSettings() = observeTmdbSettingsPipeline()

    private fun observeMdbListSettings() {
        viewModelScope.launch {
            mdbListSettingsDataStore.settings
                .distinctUntilChanged()
                .collectLatest { settings ->
                    currentMdbListSettings = settings
                    _uiState.update {
                        it.copy(
                            mdbListShowOnHero = settings.showOnHero,
                            mdbListRatingOrder = settings.enabledRatingOrder()
                        )
                    }
                }
        }
    }

    /**
     * When the watch-progress source changes (e.g. Trakt login/logout, or
     * switching between Trakt and Nuvio Sync), clear the CW disk cache and
     * in-memory state so items from the old source don't leak into the new one.
     */
    private fun observeProgressSourceChanges() {
        viewModelScope.launch {
            var previousSource: com.nuvio.tv.data.local.WatchProgressSource? = null
            var previousProfileId: Int? = null
            traktSettingsDataStore.watchProgressSource
                .collect { source ->
                    val currentProfileId = profileManager.activeProfileId.value
                    val profileChanged = previousProfileId != null && previousProfileId != currentProfileId
                    if (previousSource != null && previousSource != source && !profileChanged) {
                        // Genuine in-profile source change — clear CW caches to prevent mixing.
                        cwMetaCache.clear()
                        cwEnrichedNextUpOverlay.clear()
                        cwEnrichedInProgressOverlay.clear()
                        discoveredOlderNextUpItems.clear()
                        cwLastProcessedNextUpContentIds.clear()
                        // Clear disk cache for current profile.
                        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
                            runCatching { cwEnrichmentCache.saveNextUpSnapshot(emptyList(), force = true) }
                            runCatching { cwEnrichmentCache.saveInProgressSnapshot(emptyList(), force = true) }
                        }
                        // Reload CW from fresh source.
                        loadContinueWatching()
                    }
                    previousSource = source
                    previousProfileId = currentProfileId
                }
        }
    }

    private fun observeStartupAuthNotice() {
        viewModelScope.launch {
            authSessionNoticeDataStore.pendingNotice.collect { notice ->
                if (notice == null) return@collect
                _uiState.update { state ->
                    if (state.startupAuthNotice == notice) state else state.copy(startupAuthNotice = notice)
                }
                startupAuthNoticeJob?.cancel()
                startupAuthNoticeJob = viewModelScope.launch {
                    delay(3200)
                    clearStartupAuthNotice(notice)
                }
                authSessionNoticeDataStore.consumeNotice(notice)
            }
        }
    }

    private fun clearStartupAuthNotice(notice: StartupAuthNotice) {
        _uiState.update { state ->
            if (state.startupAuthNotice == notice) {
                state.copy(startupAuthNotice = null)
            } else {
                state
            }
        }
    }

    fun onEvent(event: HomeEvent) {
        when (event) {
            is HomeEvent.OnItemClick -> navigateToDetail(event.itemId, event.itemType)
            is HomeEvent.OnLoadMoreCatalog -> loadMoreCatalogItems(event.catalogId, event.addonId, event.type)
            is HomeEvent.OnRemoveContinueWatching -> {
                // Live TV fork: a Calendar card is just taken away (there's no progress to remove).
                if (!com.nuvio.tv.livetv.calendar.CalendarHomeFeed.dismiss(event.contentId, event.season, event.episode)) {
                    removeContinueWatching(
                        contentId = event.contentId,
                        season = event.season,
                        episode = event.episode,
                        isNextUp = event.isNextUp
                    )
                }
            }
            HomeEvent.OnRetry -> viewModelScope.launch { loadAllCatalogs(addonsCache, forceReload = true) }
        }
    }

    private fun loadContinueWatching() {
        // Immediately restore last known CW from disk cache for instant display.
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val cachedInProgress = runCatching { cwEnrichmentCache.getInProgressSnapshot() }.getOrDefault(emptyList())
            val cachedNextUp = runCatching { cwEnrichmentCache.getNextUpSnapshot() }.getOrDefault(emptyList())
            if (cachedInProgress.isEmpty() && cachedNextUp.isEmpty()) return@launch
            val dismissedNextUp = traktSettingsDataStore.dismissedNextUpKeys.first()
            // Render cached items immediately — don't wait for Trakt/allProgress.
            // The pipeline will replace these with live data once it completes.
            val inProgressItems = cachedInProgress
                .filter { !watchProgressRepository.isDroppedShow(it.contentId) }
                .map { cached ->
                    ContinueWatchingItem.InProgress(
                        progress = com.nuvio.tv.domain.model.WatchProgress(
                            contentId = cached.contentId,
                            contentType = cached.contentType,
                            name = cached.name,
                            poster = cached.poster,
                            backdrop = cached.backdrop,
                            logo = cached.logo,
                            videoId = cached.videoId,
                            season = cached.season,
                            episode = cached.episode,
                            episodeTitle = cached.episodeTitle,
                            position = cached.position,
                            duration = cached.duration,
                            lastWatched = cached.lastWatched,
                            progressPercent = cached.progressPercent
                        ),
                        episodeThumbnail = cached.episodeThumbnail,
                        episodeDescription = cached.episodeDescription,
                        episodeImdbRating = if (cached.ratingVisible) cached.episodeImdbRating else null,
                        genres = cached.genres,
                        releaseInfo = cached.releaseInfo
                    )
                }
            val nextUpItems = cachedNextUp
                .filter { !watchProgressRepository.isDroppedShow(it.contentId) }
                .filter { nextUpDismissKey(it.contentId, it.seedSeason, it.seedEpisode) !in dismissedNextUp }
                .map { cached ->
                ContinueWatchingItem.NextUp(
                    info = NextUpInfo(
                        contentId = cached.contentId,
                        contentType = cached.contentType,
                        name = cached.name,
                        poster = cached.poster,
                        backdrop = cached.backdrop,
                        logo = cached.logo,
                        videoId = cached.videoId,
                        season = cached.season,
                        episode = cached.episode,
                        episodeTitle = cached.episodeTitle,
                        episodeDescription = cached.episodeDescription,
                        thumbnail = cached.thumbnail,
                        released = cached.released,
                        hasAired = cached.hasAired,
                        airDateLabel = cached.airDateLabel,
                        lastWatched = cached.lastWatched,
                        imdbRating = if (cached.ratingVisible) cached.imdbRating else null,
                        genres = cached.genres,
                        releaseInfo = cached.releaseInfo,
                        sortTimestamp = cached.sortTimestamp,
                        releaseTimestamp = cached.releaseTimestamp,
                        isReleaseAlert = cached.isReleaseAlert,
                        isNewSeasonRelease = cached.isNewSeasonRelease,
                        seedSeason = cached.seedSeason,
                        seedEpisode = cached.seedEpisode,
                        contentLanguage = cached.contentLanguage
                    )
                )
            }
            val sortMode = layoutPreferenceDataStore.continueWatchingSortMode.first()
            val items = mergeContinueWatchingItems(
                inProgressItems = inProgressItems,
                nextUpItems = nextUpItems,
                mode = sortMode
            )
            if (items.isNotEmpty()) {
                val (mainItems, upcomingOnly) = splitUpcomingItems(items, sortMode)
                _uiState.update { it.copy(continueWatchingItems = mainItems, upcomingItems = upcomingOnly) }
                _initialCwResolved.value = true
            }
        }
        loadContinueWatchingPipeline()
    }

    private fun removeContinueWatching(
        contentId: String,
        season: Int? = null,
        episode: Int? = null,
        isNextUp: Boolean = false
    ) = removeContinueWatchingPipeline(
        contentId = contentId,
        season = season,
        episode = episode,
        isNextUp = isNextUp
    )

    private fun observeCollections() = observeCollectionsPipeline()

    private fun observeInstalledAddons() = observeInstalledAddonsPipeline()

    /**
     * Set when the catalogs were last loaded or refreshed, so returning to Home right after
     * the initial load does not immediately re-request everything. Monotonic, so a clock
     * correction cannot block or force a refresh.
     */
    internal var lastHomeCatalogRefreshAtMs: Long = 0L

    /**
     * Row the user currently has focus on, reported by the Home content as it changes. Kept out
     * of [focusState] on purpose: that one is passed down to the Home composables, and emitting
     * on every vertical move would recompose the whole row list.
     *
     * It deliberately survives leaving Home: the refresh runs on the way back in, before the row
     * list has had a chance to report focus again, so clearing it there would shield nothing.
     */
    @Volatile
    internal var liveFocusedRowKey: String? = null

    /** Called by the Home content when the focused row changes. */
    fun setLiveFocusedRowKey(rowKey: String?) {
        liveFocusedRowKey = rowKey
        onFocusedRowChangedForMdbBatch(rowKey)
    }

    /**
     * Called when Home comes back to the foreground, whether from another screen or from
     * outside the app.  Re-requests page 1 of the catalogs already loaded when the last
     * refresh is older than [HOME_CATALOG_REFRESH_TTL_MS], at most once per interval, and
     * merges each result into the row that is already on screen.
     */
    /**
     * The user pressed refresh in addon settings. Home is still on the back stack, so its
     * catalogs are re-requested right away rather than waiting for the interval or for the
     * user to come back. The same merge rules apply, so a row is never rebuilt under focus.
     */
    private fun observeManualAddonRefresh() {
        viewModelScope.launch {
            startupSyncService.manualAddonRefreshes.collect {
                if (addonsCache.isEmpty()) return@collect
                lastHomeCatalogRefreshAtMs = android.os.SystemClock.elapsedRealtime()
                refreshVisibleCatalogsPipeline(requestedByUser = true)
            }
        }
    }

    fun refreshHomeCatalogsIfStale() {
        if (addonsCache.isEmpty()) return
        val now = android.os.SystemClock.elapsedRealtime()
        if (now - lastHomeCatalogRefreshAtMs < HOME_CATALOG_REFRESH_TTL_MS) return
        lastHomeCatalogRefreshAtMs = now
        refreshVisibleCatalogsPipeline()
    }

    private suspend fun loadAllCatalogs(addons: List<Addon>, forceReload: Boolean = false) =
        loadAllCatalogsPipeline(addons, forceReload)

    private fun loadCatalog(addon: Addon, catalog: CatalogDescriptor, generation: Long) =
        loadCatalogPipeline(addon, catalog, generation)

    private fun loadMoreCatalogItems(catalogId: String, addonId: String, type: String) =
        loadMoreCatalogItemsPipeline(catalogId, addonId, type)

    internal fun scheduleUpdateCatalogRows() {
        catalogUpdateJob?.cancel()
        catalogUpdateJob = viewModelScope.launch {
            val debounceMs = when {
                // First render: use a moderate debounce so near-simultaneous
                // catalog arrivals are batched into a single heavy update pass.
                !hasRenderedFirstCatalog && hasAnyCatalogRows() -> {
                    hasRenderedFirstCatalog = true
                    150L
                }
                // During bulk loading, batch aggressively — placeholders are
                // already visible so the user won't notice the delay.
                pendingCatalogLoads > 8 -> 300L
                pendingCatalogLoads > 3 -> 250L
                pendingCatalogLoads > 0 -> 200L
                else -> 80L
            }
            delay(debounceMs)
            updateCatalogRows()
        }
    }

    /**
     * Called from the UI when a placeholder catalog row becomes visible.
     */
    fun requestLazyCatalogLoad(catalogKey: String) {
        if (catalogKey in lazyLoadRequestedKeys) {
            return
        }
        val pair = synchronized(catalogStateLock) {
            pendingLazyCatalogs.remove(catalogKey)
        }
        if (pair == null) {
            return
        }
        if (!lazyLoadRequestedKeys.add(catalogKey)) {
            return
        }
        val (addon, catalog) = pair
        val generation = catalogLoadGeneration
        pendingCatalogLoads = (pendingCatalogLoads + 1)
        loadCatalogPipeline(addon, catalog, generation)
    }

    /**
     * Load all pending lazy catalogs at once. Used when switching to GRID layout
     * which needs all catalogs available upfront.
     */
    internal fun loadAllPendingLazyCatalogs() {
        val pending = synchronized(catalogStateLock) {
            val copy = pendingLazyCatalogs.toMap()
            pendingLazyCatalogs.clear()
            copy
        }
        if (pending.isEmpty()) return
        val generation = catalogLoadGeneration
        pending.forEach { (key, pair) ->
            if (lazyLoadRequestedKeys.add(key)) {
                val (addon, catalog) = pair
                pendingCatalogLoads = (pendingCatalogLoads + 1)
                loadCatalogPipeline(addon, catalog, generation)
            }
        }
    }

    private suspend fun updateCatalogRows() = updateCatalogRowsPipeline()

    internal var posterStatusReconcileJob: Job? = null

    private fun schedulePosterStatusReconcile(rows: List<CatalogRow>) =
        schedulePosterStatusReconcilePipeline(rows)

    private fun reconcilePosterStatusObservers(rows: List<CatalogRow>) =
        reconcilePosterStatusObserversPipeline(rows)

    private fun navigateToDetail(itemId: String, itemType: String) {
        _uiState.update { it.copy(selectedItemId = itemId) }
    }

    private suspend fun enrichHeroItems(
        items: List<MetaPreview>,
        settings: TmdbSettings
    ): List<MetaPreview> = enrichHeroItemsPipeline(items, settings)

    private fun replaceGridHeroItems(
        gridItems: List<GridItem>,
        heroItems: List<MetaPreview>
    ): List<GridItem> = replaceGridHeroItemsPipeline(gridItems, heroItems)

    private fun heroEnrichmentSignature(items: List<MetaPreview>, settings: TmdbSettings): String =
        heroEnrichmentSignaturePipeline(items, settings)

    /**
     * Saves the current focus and scroll state for restoration when returning to this screen.
     */
    // When true, the next saveFocusState call is suppressed and the flag
    // is reset.  Used during layout switches to prevent the outgoing
    // layout's onDispose from poisoning the incoming layout's focus state.
    internal var suppressFocusSave: Boolean = false

    fun saveFocusState(
        verticalScrollIndex: Int,
        verticalScrollOffset: Int,
        focusedRowKey: String?,
        focusedItemKeyByRow: Map<String, String>,
        catalogRowScrollStates: Map<String, Int>,
        catalogRowScrollAnchors: Map<String, String>,
        focusedRowIndex: Int = 0,
        focusedItemIndex: Int = 0
    ) {
        if (suppressFocusSave) {
            suppressFocusSave = false
            return
        }
        val nextState = _focusState.value.copy(
            verticalScrollIndex = verticalScrollIndex,
            verticalScrollOffset = verticalScrollOffset,
            focusedRowKey = focusedRowKey,
            focusedItemKeyByRow = focusedItemKeyByRow,
            catalogRowScrollStates = catalogRowScrollStates,
            catalogRowScrollAnchors = catalogRowScrollAnchors,
            focusedRowIndex = focusedRowIndex,
            focusedItemIndex = focusedItemIndex,
            hasSavedFocus = true
        )
        if (_focusState.value == nextState) return
        _focusState.value = nextState
    }

    /**
     * Updates the stable focus target for a specific row.
     */
    fun updateFocusedItemKey(rowKey: String, itemKey: String) {
        _focusState.update { state ->
            val nextMap = state.focusedItemKeyByRow.toMutableMap()
            if (nextMap[rowKey] == itemKey) return@update state
            nextMap[rowKey] = itemKey
            state.copy(focusedItemKeyByRow = nextMap)
        }
    }

    /**
     * Updates the currently focused row key.
     */
    fun updateFocusedRowKey(rowKey: String?) {
        _focusState.update { state ->
            if (state.focusedRowKey == rowKey) state else state.copy(focusedRowKey = rowKey)
        }
    }

    /**
     * Clears the saved focus state.
     */
    fun clearFocusState() {
        _focusState.value = HomeScreenFocusState()
    }

    /**
     * Saves the grid layout focus and scroll state.
     */
    fun saveGridFocusState(
        verticalScrollIndex: Int,
        verticalScrollOffset: Int,
        focusedRowIndex: Int = 0,
        focusedItemIndex: Int = 0,
        focusedItemKey: String? = null
    ) {
        _gridFocusState.value = HomeScreenFocusState(
            verticalScrollIndex = verticalScrollIndex,
            verticalScrollOffset = verticalScrollOffset,
            focusedRowIndex = focusedRowIndex,
            focusedItemIndex = focusedItemIndex,
            focusedItemKey = focusedItemKey,
            hasSavedFocus = true
        )
    }

    override fun onCleared() {
        startupAuthNoticeJob?.cancel()
        posterStatusReconcileJob?.cancel()
        movieWatchedBatchJob?.cancel()
        seriesWatchedObserverJob?.cancel()
        cancelInFlightCatalogLoads()
        movieWatchedObserverJobs.values.forEach { it.cancel() }
        movieWatchedObserverJobs.clear()
        super.onCleared()
    }
}
