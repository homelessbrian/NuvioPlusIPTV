package com.nuvio.tv.ui.screens.home

import androidx.compose.runtime.Immutable
import com.nuvio.tv.core.tracking.TrackingMembershipRemovalConfirmation
import com.nuvio.tv.data.local.StartupAuthNotice
import com.nuvio.tv.domain.model.CatalogRow
import com.nuvio.tv.domain.model.ContinueWatchingCardStyle
import com.nuvio.tv.domain.model.Collection
import com.nuvio.tv.domain.model.FocusedPosterTrailerPlaybackTarget
import com.nuvio.tv.domain.model.HomeImdbRatingsVisibility
import com.nuvio.tv.domain.model.DetailImdbRatingsVisibility
import com.nuvio.tv.domain.model.HomeLayout
import com.nuvio.tv.domain.model.LibraryListTab
import com.nuvio.tv.domain.model.LibrarySourceMode
import com.nuvio.tv.domain.model.MetaPreview
import com.nuvio.tv.domain.model.WatchProgress

@Immutable
data class HomeUiState(
    val catalogRows: List<CatalogRow> = emptyList(),
    val continueWatchingItems: List<ContinueWatchingItem> = emptyList(),
    val upcomingItems: List<ContinueWatchingItem> = emptyList(),
    val isLoading: Boolean = true,
    val layoutPreferencesReady: Boolean = false,
    val error: String? = null,
    val selectedItemId: String? = null,
    val installedAddonsCount: Int = 0,
    val homeLayout: HomeLayout = HomeLayout.MODERN,
    val modernLandscapePostersEnabled: Boolean = false,
    val alwaysShowLandscapeClearlogo: Boolean = false,
    val modernHeroFullScreenBackdropEnabled: Boolean = false,
    val homeImdbRatingsVisibility: HomeImdbRatingsVisibility = HomeImdbRatingsVisibility.SHOW_ALL,
    val detailImdbRatingsVisibility: DetailImdbRatingsVisibility = DetailImdbRatingsVisibility.SHOW_ALL,
    val heroItems: List<MetaPreview> = emptyList(),
    val heroCatalogKeys: List<String> = emptyList(),
    val heroSectionEnabled: Boolean = true,
    val modernHomePresentation: ModernHomePresentationState = ModernHomePresentationState(),
    val posterLabelsEnabled: Boolean = true,
    val catalogAddonNameEnabled: Boolean = true,
    val catalogTypeSuffixEnabled: Boolean = true,
    val classicFocusGradientEnabled: Boolean = false,
    val focusedPosterBackdropExpandEnabled: Boolean = false,
    val focusedPosterBackdropExpandDelaySeconds: Int = 3,
    val focusedPosterBackdropTrailerEnabled: Boolean = false,
    val focusedPosterBackdropTrailerMuted: Boolean = true,
    val focusedPosterBackdropTrailerPlaybackTarget: FocusedPosterTrailerPlaybackTarget =
        FocusedPosterTrailerPlaybackTarget.HERO_MEDIA,
    val posterCardWidthDp: Int = 126,
    val posterCardHeightDp: Int = 189,
    val posterCardCornerRadiusDp: Int = 12,
    val librarySourceMode: LibrarySourceMode = LibrarySourceMode.LOCAL,
    val libraryListTabs: List<LibraryListTab> = emptyList(),
    val posterLibraryMembership: Map<String, Boolean> = emptyMap(),
    val movieWatchedStatus: Map<String, Boolean> = emptyMap(),
    val posterLibraryPending: Set<String> = emptySet(),
    val movieWatchedPending: Set<String> = emptySet(),
    val showPosterListPicker: Boolean = false,
    val posterListPickerTitle: String? = null,
    val posterListPickerContentType: String? = null,
    val posterListPickerMembership: Map<String, Boolean> = emptyMap(),
    val posterListPickerPending: Boolean = false,
    val posterListPickerError: String? = null,
    val posterListPickerRemovalConfirmations: List<TrackingMembershipRemovalConfirmation> = emptyList(),
    val gridItems: List<GridItem> = emptyList(),
    val hideUnreleasedContent: Boolean = false,
    val showFullReleaseDate: Boolean = true,
    val blurUnwatchedEpisodes: Boolean = false,
    val useEpisodeThumbnailsInCw: Boolean = true,
    val continueWatchingEnabled: Boolean = true,
    val continueWatchingCardStyle: ContinueWatchingCardStyle = ContinueWatchingCardStyle.CARD,
    val heroEnrichmentEnabled: Boolean = false,
    val startupAuthNotice: StartupAuthNotice? = null,
    val homeRows: List<HomeRow> = emptyList(),
    val customPosterUrlPattern: String = "",
    val customPosterEnabledScreens: Set<com.nuvio.tv.core.poster.CustomPosterScreen> =
        com.nuvio.tv.core.poster.CustomPosterScreen.ALL,
    val mdbListShowOnHero: Boolean = false,
    val mdbListRatingOrder: List<String> = com.nuvio.tv.domain.model.MDBListSettings.DEFAULT_RATING_ORDER
)

@Immutable
sealed class ContinueWatchingItem {
    abstract val shufflePlayback: Boolean
    @Immutable
    data class InProgress(
        val progress: WatchProgress,
        val episodeDescription: String? = null,
        val episodeThumbnail: String? = null,
        val episodeImdbRating: Float? = null,
        val genres: List<String> = emptyList(),
        val releaseInfo: String? = null,
        val contentLanguage: String? = null,
        override val shufflePlayback: Boolean = false,
        val originalPoster: String? = null,
        val customLandscapePoster: String? = null,
        val mdbListRatings: com.nuvio.tv.domain.model.MDBListRatings? = null
    ) : ContinueWatchingItem()

    @Immutable
    data class NextUp(
        val info: NextUpInfo,
        override val shufflePlayback: Boolean = false,
        val originalPoster: String? = null,
        val customLandscapePoster: String? = null
    ) : ContinueWatchingItem()
}

val ContinueWatchingItem.shuffleFocusKey: String?
    get() = if (!shufflePlayback) null else when (this) {
        is ContinueWatchingItem.InProgress -> "cw_shuffle_${progress.contentId}"
        is ContinueWatchingItem.NextUp -> "cw_shuffle_${info.contentId}"
    }

@Immutable
data class NextUpInfo(
    val contentId: String,
    val contentType: String,
    val name: String,
    val poster: String?,
    val backdrop: String?,
    val logo: String?,
    val videoId: String,
    val season: Int,
    val episode: Int,
    val episodeTitle: String?,
    val episodeDescription: String? = null,
    val thumbnail: String?,
    val released: String? = null,
    val hasAired: Boolean = true,
    val airDateLabel: String? = null,
    val lastWatched: Long,
    val imdbRating: Float? = null,
    val genres: List<String> = emptyList(),
    val releaseInfo: String? = null,
    val sortTimestamp: Long,
    val releaseTimestamp: Long? = null,
    val isReleaseAlert: Boolean = false,
    val isNewSeasonRelease: Boolean = false,
    val seedSeason: Int? = null,
    val seedEpisode: Int? = null,
    val contentLanguage: String? = null,
    val mdbListRatings: com.nuvio.tv.domain.model.MDBListRatings? = null,
    /** Live TV fork: a card from the Calendar (a show whose bell is rung, or an upcoming episode). */
    val fromCalendar: Boolean = false
)

@Immutable
sealed class HomeRow {
    @Immutable
    data class Catalog(val row: CatalogRow) : HomeRow()

    @Immutable
    data class CollectionRow(val collection: Collection) : HomeRow()

    /**
     * Placeholder for a catalog row whose data hasn't been fetched yet.
     * Rendered as a shimmer/skeleton row until the user scrolls near it
     * and the actual catalog data is loaded on demand.
     */
    @Immutable
    data class PlaceholderCatalog(
        val catalogKey: String,
        val stableCatalogKey: String,
        val addonId: String,
        val addonName: String,
        val addonBaseUrl: String,
        val catalogId: String,
        val catalogName: String,
        val apiType: String,
        val displayTitle: String
    ) : HomeRow()
}

@Immutable
sealed class GridItem {
    @Immutable
    data class Hero(val items: List<MetaPreview>) : GridItem()
    @Immutable
    data class SectionDivider(
        val catalogName: String,
        val catalogId: String,
        val addonBaseUrl: String,
        val addonId: String,
        val type: String
    ) : GridItem()
    @Immutable
    data class Content(
        val item: MetaPreview,
        val addonBaseUrl: String,
        val catalogId: String,
        val catalogName: String,
        /** Row this card belongs to, so the grid can report which row holds focus. */
        val addonId: String = ""
    ) : GridItem()
    @Immutable
    data class SeeAll(
        val catalogId: String,
        val addonId: String,
        val addonBaseUrl: String,
        val type: String
    ) : GridItem()
    @Immutable
    data class CollectionHeader(
        val collectionId: String,
        val title: String
    ) : GridItem()
    @Immutable
    data class CollectionFolder(
        val collectionId: String,
        val collectionTitle: String,
        val focusGlowEnabled: Boolean,
        val folder: com.nuvio.tv.domain.model.CollectionFolder
    ) : GridItem()
}

sealed class HomeEvent {
    data class OnItemClick(val itemId: String, val itemType: String) : HomeEvent()
    data class OnLoadMoreCatalog(val catalogId: String, val addonId: String, val type: String) : HomeEvent()
    data class OnRemoveContinueWatching(
        val contentId: String,
        val season: Int? = null,
        val episode: Int? = null,
        val isNextUp: Boolean = false
    ) : HomeEvent()
    data object OnRetry : HomeEvent()
}

fun homeItemStatusKey(itemId: String, itemType: String): String {
    return "${itemType.lowercase()}|$itemId"
}
